import AdSupport
import CoreTelephony
import CoreMotion
import Network
import Contacts
import AppTrackingTransparency
import CoreLocation
import Flutter
import Security
import UIKit

final class ClinkNativeDeviceInfo {
    
    private let monitor = NWPathMonitor()
    
    private let motionManager = CMMotionManager()
    
    static func register(messenger: FlutterBinaryMessenger) {
        let instance = ClinkNativeDeviceInfo()
        let channel = FlutterMethodChannel(
            name: "flutter_native_channel",
            binaryMessenger: messenger
        )
        channel.setMethodCallHandler { call, result in
            switch call.method {
            case "openNativeAppSettings":
                if let setUrl = URL(string: UIApplication.openSettingsURLString) {
                    
                    DispatchQueue.main.async {
                        UIApplication.shared.open(setUrl, options: [:], completionHandler: nil)
                    }
                    
                }
                result(true)
            case "getDeviceInfo":
                result(buildDeviceInfo())
            case "getWords":
                result(SecurityManager.shared.check().json())
            case "getDevicePlacementState":
                instance.getDevicePose(result: result)
            case "isUsingProxy":
                result(instance.isUsingProxy())
            case "getCarrierName":
                result(instance.getCarrierName())
            case "getNetworkType":
                result(instance.getNetworkType())
            case "getHwModel":
                result(instance.getSysctlValue("hw.model"))
            case "getMainSimAvailable":
                result(instance.isMainSimAvailable())
            case "isUsingVPN":
                result(instance.isUsingVPN())
            case "getSubSimAvailable":
                result(instance.isSubSimAvailable())
            case "getNativeDeviceToken":
                result("")
            case "getLiebiao":
                result(loadSchemesFromInfoPlist())
            case "getHaves":
                result(instance.getHaves())
            case "contactPermissionLevel":
                let status = CNContactStore.authorizationStatus(for: .contacts)
                if #available(iOS 18.0, *) {
                    switch status {
                    case .authorized:
                        result("full")
                    case .limited:
                        result("limited")
                    case .denied:
                        result("denied")
                    case .notDetermined:
                        result("notDetermined")
                    default:
                        result("unknown")
                    }
                    
                } else {
                    switch status {
                    case .authorized:
                        result("full")
                    case .denied:
                        result("denied")
                    case .notDetermined:
                        result("notDetermined")
                    default:
                        result("unknown")
                    }
                }
            default:
                result(FlutterMethodNotImplemented)
            }
        }
    }
    
    private static func buildDeviceInfo() -> [String: Any] {
        let memory = memoryInfo()
        let disk = diskInfo()
        
        return [
            "mobDeviceId": KeychainHelper.shared.getDeviceId(),
            "bundleId": Bundle.main.bundleIdentifier ?? "",
            "osVersion": "\(UIDevice.current.systemName)\(UIDevice.current.systemVersion)",
            "idfa": idfaIfAuthorized(),
            "ip": "0.0.0.0",
            "MemoryTotal": NSNumber(value: memory.total),
            "MemoryFree": NSNumber(value: memory.free),
            "MemoryUsed": NSNumber(value: memory.used),
            "DiskTotal": NSNumber(value: disk.total),
            "DiskFree": NSNumber(value: disk.free),
            "ProcessUptime": NSNumber(value: getProcessUptime()),
        ]
    }
    
    private static func idfaIfAuthorized() -> String {
        if #available(iOS 14.0, *) {
            guard ATTrackingManager.trackingAuthorizationStatus == .authorized else {
                return ""
            }
            return ASIdentifierManager.shared().advertisingIdentifier.uuidString
        }
        
        guard ASIdentifierManager.shared().isAdvertisingTrackingEnabled else {
            return ""
        }
        return ASIdentifierManager.shared().advertisingIdentifier.uuidString
    }
    
    private static func memoryInfo() -> (total: Int64, free: Int64, used: Int64) {
        let total = Int64(ProcessInfo.processInfo.physicalMemory / 1024 / 1024)
        return (total, -1, -1)
    }
    
    private static func diskInfo() -> (total: Int64, free: Int64) {
        guard
            let values = try? FileManager.default.attributesOfFileSystem(
                forPath: NSHomeDirectory()
            ),
            let total = values[.systemSize] as? NSNumber,
            let free = values[.systemFreeSize] as? NSNumber
        else {
            return (-1, -1)
        }
        
        return (total.int64Value / 1024 / 1024, free.int64Value / 1024 / 1024)
    }
    
    private static func getProcessUptime() -> Int {
        // systemUptime = số giây từ khi boot đến bây giờ
        let systemUptime = ProcessInfo.processInfo.systemUptime
        
        // Thời điểm boot = hiện tại - systemUptime
        let bootDate = Date().addingTimeInterval(-systemUptime)
        
        // Convert sang timestamp (seconds since 1970)
        let bootTimestamp = Int(bootDate.timeIntervalSince1970)
        
        print("come oth e- - -  -- - \(bootTimestamp)=============\(bootTimestamp * 1000)")
        
        return (bootTimestamp * 1000)
        
    }
    
    private func getHaves() -> [String: Bool] {
        
        let vneid = isHave(scheme: "vneid")
        let zalo = isHave(scheme: "zalo")
        
        print("come to here - - - -- - - - - -- - vneid- \(vneid)")
        print("come to here - - - -- - - - - -- - zalo- \(zalo)")
        
        return ["haveVneid": vneid, "haveZalo": zalo]
    }
    
    private func getIPAddress(preferIPv4: Bool = true) -> String? {
        var address : String?
        
        var ifaddr : UnsafeMutablePointer<ifaddrs>?
        guard getifaddrs(&ifaddr) == 0, let firstAddr = ifaddr else {
            return nil
        }
        
        for ptr in sequence(first: firstAddr, next: { $0.pointee.ifa_next }) {
            let interface = ptr.pointee
            
            let addrFamily = interface.ifa_addr.pointee.sa_family
            if addrFamily == UInt8(AF_INET) || addrFamily == UInt8(AF_INET6) {
                let name = String(cString: interface.ifa_name)
                if name == "en0" || name == "pdp_ip0" {
                    var hostname = [CChar](repeating: 0, count: Int(NI_MAXHOST))
                    getnameinfo(interface.ifa_addr,
                                socklen_t(interface.ifa_addr.pointee.sa_len),
                                &hostname, socklen_t(hostname.count),
                                nil, socklen_t(0), NI_NUMERICHOST)
                    address = String(cString: hostname)
                    break
                }
            }
        }
        
        freeifaddrs(ifaddr)
        return address
    }
    
    private func getDevicePose(result: @escaping FlutterResult) {
        
        guard motionManager.isDeviceMotionAvailable else {
            result(0)
            return
        }
        
        motionManager.deviceMotionUpdateInterval = 0.1
        
        motionManager.startDeviceMotionUpdates(to: .main) { [weak self] motion, error in
            
            guard let gravity = motion?.gravity else {
                result(0)
                return
            }
            
            let x = abs(gravity.x)
            let y = abs(gravity.y)
            let z = abs(gravity.z)
            
            self?.motionManager.stopDeviceMotionUpdates()
            
            // 1：水平
            if z > 0.85 {
                result(1)
            }
            // 3：垂直
            else if x > 0.75 || y > 0.75 {
                result(3)
            }
            // 2：倾斜
            else {
                result(2)
            }
        }
    }
    
    private func isUsingProxy() -> Bool {
        
        guard let dict = CFNetworkCopySystemProxySettings()?.takeRetainedValue()
                as? NSDictionary else {
            return false
        }
        
        let http  = dict["HTTPEnable"] as? Int ?? 0
        let https = dict["HTTPSEnable"] as? Int ?? 0
        let socks = dict["SOCKSEnable"] as? Int ?? 0
        
        return http == 1 || https == 1 || socks == 1
    }
    
    private func isUsingVPN() -> Bool {
        
        guard let settings =
                CFNetworkCopySystemProxySettings()?.takeRetainedValue()
                as? [String: Any],
              let scoped =
                settings["__SCOPED__"] as? [String: Any]
        else {
            return false
        }
        
        let keys = scoped.keys
        
        for key in keys {
            
            if key.contains("tap") ||
                key.contains("tun") ||
                key.contains("ppp") ||
                key.contains("ipsec") ||
                key.contains("utun") {
                
                return true
            }
        }
        
        return false
    }
    
    private func getCarrierName() -> String {
        
        let networkInfo = CTTelephonyNetworkInfo()
        
        // iOS 12+
        if let carriers = networkInfo.serviceSubscriberCellularProviders {
            
            for (_, carrier) in carriers {
                
                if let name = carrier.carrierName,
                   !name.isEmpty {
                    return name
                }
            }
        }
        
        return ""
    }
    
    private func getSysctlValue(_ key: String) -> String {
        
        var size: size_t = 0
        
        sysctlbyname(key, nil, &size, nil, 0)
        
        var machine = [CChar](repeating: 0, count: size)
        
        sysctlbyname(key, &machine, &size, nil, 0)
        
        return String(cString: machine)
    }
    
    private func isMainSimAvailable() -> Bool {
        
        let networkInfo = CTTelephonyNetworkInfo()
        
        guard let carriers =
                networkInfo.serviceSubscriberCellularProviders,
              let radioTech =
                networkInfo.serviceCurrentRadioAccessTechnology
        else {
            return false
        }
        
        let keys = Array(carriers.keys)
        
        guard keys.count >= 1 else {
            return false
        }
        
        let key = keys[0]
        
        let carrier = carriers[key]
        let tech = radioTech[key]
        
        return carrier?.carrierName?.isEmpty == false &&
        tech != nil
    }
    
    private func isSubSimAvailable() -> Bool {
        
        let networkInfo = CTTelephonyNetworkInfo()
        
        guard let carriers =
                networkInfo.serviceSubscriberCellularProviders,
              let radioTech =
                networkInfo.serviceCurrentRadioAccessTechnology
        else {
            return false
        }
        
        let keys = Array(carriers.keys)
        
        guard keys.count >= 2 else {
            return false
        }
        
        let key = keys[1]
        
        let carrier = carriers[key]
        let tech = radioTech[key]
        
        return carrier?.carrierName?.isEmpty == false &&
        tech != nil
    }
    
    private func getNetworkType() -> String {
        
        // WiFi
        if monitor.currentPath.usesInterfaceType(.wifi) {
            return "WIFI"
        }
        
        // 无网络
        if monitor.currentPath.status != .satisfied {
            return "UNKNOWN"
        }
        
        let networkInfo = CTTelephonyNetworkInfo()
        
        guard let serviceId = networkInfo.dataServiceIdentifier,
              let radio =
                networkInfo.serviceCurrentRadioAccessTechnology?[serviceId]
        else {
            return "UNKNOWN"
        }
        
        if #available(iOS 14.1, *) {
            if radio == CTRadioAccessTechnologyNR ||
                radio == CTRadioAccessTechnologyNRNSA {
                return "5G"
            }
            
        }
        
        switch radio {
            
        case CTRadioAccessTechnologyLTE:
            return "4G"
            
        case CTRadioAccessTechnologyWCDMA,
            CTRadioAccessTechnologyHSDPA,
            CTRadioAccessTechnologyHSUPA,
            CTRadioAccessTechnologyCDMAEVDORev0,
            CTRadioAccessTechnologyCDMAEVDORevA,
            CTRadioAccessTechnologyCDMAEVDORevB,
        CTRadioAccessTechnologyCDMA1x:
            return "3G"
            
        case CTRadioAccessTechnologyEdge,
        CTRadioAccessTechnologyGPRS:
            return "2G"
            
        default:
            return "UNKNOWN"
        }
        
    }
}

final class KeychainHelper {
    static let shared = KeychainHelper()
    
    private let service = Bundle.main.bundleIdentifier ?? "flutter_runner"
    private let account = "flutter_device_unique_id"
    
    func getDeviceId() -> String {
        if let saved = read(account: account) { return saved }
        
        let newId = UUID().uuidString
        save(value: newId, account: account)
        return newId
    }
    
    private func save(value: String, account: String) {
        let data = Data(value.utf8)
        delete(account: account)
        
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: data,
        ]
        
        SecItemAdd(query as CFDictionary, nil)
    }
    
    private func read(account: String) -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne,
        ]
        
        var result: AnyObject?
        let status = SecItemCopyMatching(query as CFDictionary, &result)
        
        guard
            status == errSecSuccess,
            let data = result as? Data,
            let value = String(data: data, encoding: .utf8)
        else {
            return nil
        }
        
        return value
    }
    
    private func delete(account: String) {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
        ]
        
        SecItemDelete(query as CFDictionary)
    }
}
