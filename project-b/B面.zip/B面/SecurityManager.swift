//
//  SecurityManager.swift
//  Runner
//
//  Created by 陈开琛 on 2026/8/3.
//

import Foundation
import IOSSecuritySuite
import SystemConfiguration
import MachO

struct SecurityResult {
    
    let jailbreak: Bool
    let frida: Bool
    let debugger: Bool
    let simulator: Bool
    let proxy: Bool
    let sandboxEscape: Bool
    
    /// 风险等级
    /// 0 安全
    /// 1 低风险
    /// 2 中风险
    /// 3 高风险
    var riskLevel: Int {
        
        if jailbreak || frida || sandboxEscape {
            return 3
        }
        
        if debugger {
            return 2
        }
        
        if proxy {
            return 1
        }
        
        return 0
    }
    
    var message:String {
        var arr:[String] = []
        
        if jailbreak {
            arr.append("jailbreak")
        }
        
        if frida {
            arr.append("frida")
        }
        
        if debugger {
            arr.append("debugger")
        }
        
        if simulator {
            arr.append("simulator")
        }
        
        if proxy {
            arr.append("proxy")
        }
        
        if sandboxEscape {
            arr.append("sandbox_escape")
        }
        
        return arr.joined(separator: ",")
    }
    
    func json()->[String:Any] {
        
        return [
            "jailbreak": jailbreak,
            "frida": frida,
            "debugger": debugger,
            "simulator": simulator,
            "proxy": proxy,
            "sandboxEscape": sandboxEscape,
            "riskLevel": riskLevel,
            "message": message
        ]
    }
}

final class SecurityManager {
    
    static let shared = SecurityManager()
    
    private init(){}
    
    // MARK: 全量检测
    func check() -> SecurityResult {
        
        let jailbreak = checkJailbreak()
        
        let frida = checkFrida()
        
        let debugger = IOSSecuritySuite.amIDebugged()
        
        let simulator = checkSimulator()
        
        let proxy = IOSSecuritySuite.amIProxied()
        
        let sandbox = checkSandboxEscape()
        
        let result =
        SecurityResult(
            jailbreak: jailbreak,
            frida: frida,
            debugger: debugger,
            simulator: simulator,
            proxy: proxy,
            sandboxEscape: sandbox
        )
        
        // print("""
        // ===== Security Check =====
        // \(result.json())
        // ==========================
        // """)
        
        return result
    }
}


// MARK: - 越狱检测
extension SecurityManager {
    
    private func checkJailbreak()
    -> Bool {
        
        let paths:[String] = [
            
            "/Applications/Cydia.app",
            "/Applications/Sileo.app",
            "/Applications/Zebra.app",
            "/Applications/Filza.app",
            "/usr/bin/ssh",
            "/usr/sbin/sshd",
            "/private/var/lib/apt",
            "/usr/bin/frida-server"
            
        ]
        
        for path in paths {
            if FileManager.default.fileExists(atPath:path){
                
                return true
            }
            
        }
        
        return IOSSecuritySuite.amIJailbroken()
        
    }
    
}

// MARK: - Frida / Hook检测
extension SecurityManager {
    
    private func checkFrida() -> Bool {
        
        let count = _dyld_image_count()
        
        let keywords:[String] = [
            "frida",
            "fridagadget",
            "substrate",
            "mobilesubstrate",
            "substitute",
            "libhooker"
            
        ]
        
        for index in 0..<count {
            
            guard let name = _dyld_get_image_name(index) else { continue }
            
            let image = String(cString:name).lowercased()
            
            for key in keywords {
                
                if image.contains(key){
                    
                    return true
                }
                
            }
            
        }
        
        return false
        
    }
    
}

// MARK: - Sandbox逃逸检测
extension SecurityManager {
    
    private func checkSandboxEscape() -> Bool {
        
        let path = "/private/security_test.txt"
        
        do {
            try "test".write(
                toFile:path,
                atomically:true,
                encoding:.utf8
            )
            
            try? FileManager.default.removeItem(atPath:path)
            
            return true
            
        }catch{
            return false
        }
        
    }
    
}

// MARK: - 模拟器检测
extension SecurityManager {
    private func checkSimulator() -> Bool {
        
#if targetEnvironment(simulator)
        
        return true
        
#else
        return IOSSecuritySuite.amIRunInEmulator()
        
#endif
        
    }
    
}

