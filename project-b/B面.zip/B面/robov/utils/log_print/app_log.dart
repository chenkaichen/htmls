// ignore_for_file: non_constant_identifier_names

import 'dart:developer' as developer;
import 'dart:io';

import 'package:homewallet/core/app_public_constants.dart';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';

void LogError(String scope, Object error, StackTrace stackTrace) {
  debugPrint('[${AppPublicConstants.appName}][$scope] $error');
  debugPrint(stackTrace.toString());
}

void LogDebug(String scope, Object message) {
  if (!kDebugMode) return;
  debugPrint('[${AppPublicConstants.appName}][$scope] $message');
}

void logLong(String content) {
  if (!kDebugMode) return;
  developer.log(
    ' [${AppPublicConstants.appName}]--------------------------------\n$content\n',
  );
}

Future<void> logDebugToFile(String scope, String text) async {
  final dir = await getApplicationDocumentsDirectory();
  final file = File('${dir.path}/${AppPublicConstants.appName}_debug_log.txt');

  final cutoffDate = DateTime.now().subtract(const Duration(days: 365 * 20));

  await file.writeAsString(
    ' [${AppPublicConstants.appName}][$scope]-----$cutoffDate---------------------------\n$text\n',
    mode: FileMode.write,
    flush: true,
  );

  logLong("✅ 日志已写入: ${file.path}");
}
