import 'package:dio/dio.dart';
import 'package:go_router/go_router.dart';
import 'package:homewallet/app/di.dart';
import 'package:homewallet/app/router.dart';
import 'package:homewallet/features/auth/application/auth_providers.dart';
import 'package:homewallet/main.dart';
import 'package:homewallet/robov/utils/navigation/navigation_service.dart';
import '../hud/custom_snackbar.dart';
import 'api_client.dart';
import 'error_handler/api_error_handler.dart';
import 'exceptions/api_exception.dart';
import 'base_response.dart';

abstract class BaseRepository {
  final ApiClient _apiClient = ApiClient();

  ApiClient get apiClient => _apiClient;

  Future<T?> safeApiCall<T>({
    required Future<Response> Function() apiCall,
    required T? Function(dynamic) onSuccess,
    bool isWebRequest = false,
  }) async {
    try {
      final response = await apiCall();

      // Parse base response
      final baseResponse = BaseResponse.fromJson(
        response.data as Map<String, dynamic>,
        null,
      );

      if (!baseResponse.isSuccess) {
        if (baseResponse.errorCode?.contains('401') == true) {
          final authController = providerContainer.read(authControllerProvider);
          await authController.signOut();
          providerContainer.read(appStartupProvider).setSignedOut();
          NavigationService.context?.go(AppRoutes.authLogin);

          CustomSnackbar.error(
            'Thông tin xác thực đã hết hạn, vui lòng đăng nhập lại',
          );
          return null;
        }

        throw ApiException(
          type: ApiExceptionType.businessLogic,
          message: baseResponse.msg ?? 'Business error',
          statusCode: response.statusCode,
        );
      }

      if (isWebRequest) {
        return onSuccess(response.data);
      } else {
        return onSuccess(baseResponse.data);
      }
    } on ApiException {
      rethrow;
    } catch (error) {
      throw ApiErrorHandler.handleError(error);
    }
  }

  Future<BaseResponse<T>> safeApiCallWithBaseResponse<T>({
    required Future<Response> Function() apiCall,
    T? Function(dynamic)? fromJsonT,
  }) async {
    try {
      final response = await apiCall();

      // Parse base response
      final baseResponse = BaseResponse<T>.fromJson(
        response.data as Map<String, dynamic>,
        fromJsonT,
      );

      // Check business logic success
      if (!baseResponse.isSuccess) {
        throw ApiException(
          type: ApiExceptionType.businessLogic,
          message: baseResponse.msg ?? 'Business error',
          statusCode: response.statusCode,
        );
      }

      return baseResponse;
    } on ApiException {
      rethrow;
    } catch (error) {
      throw ApiErrorHandler.handleError(error);
    }
  }
}
