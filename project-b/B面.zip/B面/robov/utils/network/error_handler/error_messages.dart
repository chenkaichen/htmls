import '../exceptions/api_exception.dart';

class ErrorMessages {
  // Network Errors
  static const String noInternet =
      'Không có kết nối mạng. Vui lòng kiểm tra và thử lại.';
  static const String connectionTimeout = 'Kết nối quá chậm. Vui lòng thử lại.';
  static const String requestTimeout =
      'Yêu cầu hết thời gian chờ. Vui lòng thử lại.';

  // Server Errors
  static const String serverError = 'Lỗi hệ thống. Vui lòng thử lại sau.';
  static const String internalServerError =
      'Lỗi máy chủ. Vui lòng thử lại sau.';
  static const String serviceUnavailable =
      'Dịch vụ tạm thời không khả dụng. Vui lòng thử lại sau.';

  // Auth Errors
  static const String unauthorized =
      'Phiên đăng nhập đã hết hạn. Vui lòng đăng nhập lại.';
  static const String forbidden =
      'Bạn không có quyền truy cập. Vui lòng liên hệ hỗ trợ.';

  // Resource Errors
  static const String notFound = 'Không tìm thấy dữ liệu. Vui lòng thử lại.';

  // Business Logic Errors
  static const String invalidOtp =
      'Mã xác nhận không đúng. Vui lòng kiểm tra lại.';
  static const String expiredOtp =
      'Mã xác nhận đã hết hạn. Vui lòng lấy mã mới.';
  static const String phoneNotRegistered =
      'Số điện thoại chưa đăng ký. Vui lòng kiểm tra lại.';
  static const String phoneAlreadyExists = 'Số điện thoại đã được sử dụng.';

  // General Errors
  static const String unexpectedError = 'Đã có lỗi xảy ra. Vui lòng thử lại.';
  static const String requestCancelled = 'Yêu cầu đã bị hủy.';

  // Map exception type to user-friendly message
  static String getMessageForException(ApiException exception) {
    switch (exception.type) {
      case ApiExceptionType.network:
        if (exception.originalError.toString().contains('SocketException')) {
          return noInternet;
        }
        return connectionTimeout;

      case ApiExceptionType.timeout:
        return requestTimeout;

      case ApiExceptionType.unauthorized:
        return unauthorized;

      case ApiExceptionType.forbidden:
        return forbidden;

      case ApiExceptionType.notFound:
        return notFound;

      case ApiExceptionType.server:
        if (exception.statusCode == 500) {
          return internalServerError;
        } else if (exception.statusCode == 503) {
          return serviceUnavailable;
        }
        return serverError;

      case ApiExceptionType.businessLogic:
        // Map business error codes to specific messages
        return _mapBusinessErrorMessage(exception.message);

      case ApiExceptionType.cancel:
        return requestCancelled;

      case ApiExceptionType.unexpected:
        return unexpectedError;
    }
  }

  // Map business error codes or messages to user-friendly messages
  static String _mapBusinessErrorMessage(String originalMessage) {
    // Add your business error code mapping here
    // Example:
    if (originalMessage.contains('INVALID_OTP')) {
      return invalidOtp;
    } else if (originalMessage.contains('EXPIRED_OTP')) {
      return expiredOtp;
    } else if (originalMessage.contains('PHONE_NOT_FOUND')) {
      return phoneNotRegistered;
    } else if (originalMessage.contains('PHONE_EXISTS')) {
      return phoneAlreadyExists;
    }

    // Default fallback
    return unexpectedError;
  }
}
