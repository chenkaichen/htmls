import 'package:homewallet/core/app_public_constants.dart';
import 'package:dio/dio.dart';
import '../exceptions/api_exception.dart';
import '../base_response.dart';

class ApiErrorHandler {
  static ApiException handleError(dynamic error) {
    if (error is DioException) {
      return _handleDioException(error);
    } else if (error is ApiException) {
      return error;
    } else {
      return ApiException(
        type: ApiExceptionType.unexpected,
        message: error.toString(),
        originalError: error,
      );
    }
  }

  static ApiException _handleDioException(DioException error) {
    switch (error.type) {
      case DioExceptionType.connectionTimeout:
      case DioExceptionType.sendTimeout:
      case DioExceptionType.receiveTimeout:
        return ApiException(
          type: ApiExceptionType.timeout,
          message: 'Request timeout',
          originalError: error,
        );

      case DioExceptionType.connectionError:
        return ApiException(
          type: ApiExceptionType.network,
          message: 'Network connection error',
          originalError: error,
        );

      case DioExceptionType.badResponse:
        return _handleBadResponse(error);

      case DioExceptionType.cancel:
        return ApiException(
          type: ApiExceptionType.cancel,
          message: 'Request cancelled',
          originalError: error,
        );

      case DioExceptionType.unknown:
        if (error.error.toString().contains('SocketException')) {
          return ApiException(
            type: ApiExceptionType.network,
            message: 'No internet connection',
            originalError: error,
          );
        }
        return ApiException(
          type: ApiExceptionType.unexpected,
          message: error.message ?? 'Unknown error',
          originalError: error,
        );

      default:
        return ApiException(
          type: ApiExceptionType.unexpected,
          message: 'Unexpected error',
          originalError: error,
        );
    }
  }

  static ApiException _handleBadResponse(DioException error) {
    final statusCode = error.response?.statusCode;

    switch (statusCode) {
      case 401:
        return ApiException(
          type: ApiExceptionType.unauthorized,
          message: 'Unauthorized',
          statusCode: statusCode,
          originalError: error,
        );

      case 403:
        return ApiException(
          type: ApiExceptionType.forbidden,
          message: 'Forbidden',
          statusCode: statusCode,
          originalError: error,
        );

      case 404:
        return ApiException(
          type: ApiExceptionType.notFound,
          message: 'Not found',
          statusCode: statusCode,
          originalError: error,
        );

      case 500:
      case 502:
      case 503:
        return ApiException(
          type: ApiExceptionType.server,
          message: 'Server error',
          statusCode: statusCode,
          originalError: error,
        );

      default:
        // Try to parse business logic error from response
        return _parseBusinessLogicError(error);
    }
  }

  static ApiException _parseBusinessLogicError(DioException error) {
    try {
      final response = error.response?.data;
      if (response is Map<String, dynamic>) {
        final baseResponse = BaseResponse.fromJson(response, null);

        // If code is not success code, it's a business logic error
        if (baseResponse.code != RequestApiConstants.successCode) {
          return ApiException(
            type: ApiExceptionType.businessLogic,
            message: baseResponse.msg ?? 'Business logic error',
            statusCode: error.response?.statusCode,
            originalError: error,
          );
        }
      }
    } catch (e) {
      // If parsing fails, return server error
    }

    return ApiException(
      type: ApiExceptionType.server,
      message: 'Server error',
      statusCode: error.response?.statusCode,
      originalError: error,
    );
  }
}
