import 'dart:async';
import 'package:dio/dio.dart';
import '../../hud/hud_tool.dart';

class LoadingInterceptor extends Interceptor {
  LoadingInterceptor({
    this.enableDelay = true,
    this.delayDuration = const Duration(milliseconds: 500),
  });

  final bool enableDelay;

  final Duration delayDuration;

  Timer? _delayTimer;

  int _activeRequests = 0;

  bool _loadingShown = false;

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    if (_shouldShowLoading(options)) {
      _activeRequests++;

      if (_activeRequests == 1) {
        if (enableDelay) {
          _delayTimer?.cancel();

          _delayTimer = Timer(delayDuration, () {
            if (_activeRequests > 0 && !_loadingShown) {
              _loadingShown = true;
              JCHUDTool.showLoading(text: _getLoadingText(options));
            }
          });
        } else {
          _loadingShown = true;
          JCHUDTool.showLoading(text: _getLoadingText(options));
        }
      }
    }

    handler.next(options);
  }

  @override
  void onResponse(Response response, ResponseInterceptorHandler handler) {
    _finishRequest(response.requestOptions);

    handler.next(response);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    _finishRequest(err.requestOptions);

    handler.next(err);
  }

  void _finishRequest(RequestOptions options) {
    if (!_shouldShowLoading(options)) {
      return;
    }

    _activeRequests--;

    if (_activeRequests > 0) {
      return;
    }

    _activeRequests = 0;

    _delayTimer?.cancel();
    _delayTimer = null;

    if (_loadingShown) {
      _loadingShown = false;
      JCHUDTool.dismissLoading();
    }
  }

  bool _shouldShowLoading(RequestOptions options) {
    final value = options.extra['showLoading'];

    if (value is bool) {
      return value;
    }

    return true;
  }

  String _getLoadingText(RequestOptions options) {
    final value = options.extra['loadingText'];

    if (value is String) {
      return value;
    }

    return 'Đang tải...';
  }
}
