// import 'dart:convert';

import 'dart:convert';
import 'package:homewallet/core/app_public_constants.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:homewallet/features/auth/data/auth_session_store.dart';

import '../../log_print/app_log.dart';

class AuthInterceptor extends Interceptor {
  @override
  Future<void> onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    try {
      final sessionStore = SecureAuthSessionStore();

      final token = (await sessionStore.read())?.token ?? '';

      if (token.isNotEmpty) {
        options.headers['Authorization'] = 'Bearer $token';
      }

      options.headers['X-App-Package'] = AppPublicConstants.appBundleId;
      options.headers['APP-Version'] = AppPublicConstants.appFullVersion;
      options.headers['APP-Version-Code'] = AppPublicConstants.appFullVersion;
      options.headers['Accept-Language'] = 'vi';
      options.headers['APP-Client'] = 'ios';
      options.headers['APP-Name'] = AppPublicConstants.appName;
      options.headers['X-Device-Manufacturer'] = 'apple';
      options.headers['X-Timestamp'] = DateTime.now().millisecondsSinceEpoch
          .toString();
      options.headers['X-Device-Id'] = await _getDeviceIdFromNative();

      logLong('options.headers: ${jsonEncode(options.headers)}');
    } catch (e) {
      // If storage service not available, continue without token
    }

    handler.next(options);
  }

  /// 从原生获取iOS部分设备信息
  Future<String> _getDeviceIdFromNative() async {
    const deviceChannel = MethodChannel('flutter_native_channel');

    final result = await deviceChannel.invokeMethod<Map<dynamic, dynamic>>(
      'getDeviceInfo',
    );
    final map = Map<String, dynamic>.from(result ?? {});

    return map['mobDeviceId'] ?? '';
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    // Handle 401 - token expired, navigate to login
    if (err.response?.statusCode == 401) {
      try {
        // AuthService.logout();
      } catch (e) {
        debugPrint('AuthInterceptor---Error in onError: $e');
      }
    }

    handler.next(err);
  }
}
