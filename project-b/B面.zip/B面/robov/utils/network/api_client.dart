import 'dart:convert';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter/foundation.dart';
import 'package:homewallet/core/app_public_constants.dart';
import '../log_print/app_log.dart';
import 'encrypt/encrypt_tool.dart';
import 'interceptors/auth_interceptor.dart';
import 'interceptors/loading_interceptor.dart';

class ApiClient {
  static final ApiClient _instance = ApiClient._internal();
  late final Dio _dio;

  static final RequestEncryptTool encryptTool = RequestEncryptTool();

  factory ApiClient() {
    return _instance;
  }

  ApiClient._internal() {
    _dio = Dio(
      BaseOptions(
        baseUrl: AppPublicConstants.apiBaseUrl,
        connectTimeout: const Duration(seconds: 60),
        receiveTimeout: const Duration(seconds: 60),
        sendTimeout: const Duration(seconds: 60),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        responseType: ResponseType.json,
        validateStatus: (status) => status != null && status < 500,
      ),
    );

    if (kDebugMode) {
      (_dio.httpClientAdapter as IOHttpClientAdapter).createHttpClient = () {
        final client = HttpClient();
        client.badCertificateCallback = (cert, host, port) => true;
        return client;
      };
    }

    _setupInterceptors();
  }

  void _setupInterceptors() {
    // Auth Interceptor
    _dio.interceptors.add(AuthInterceptor());
    _dio.interceptors.add(LoadingInterceptor());
  }

  Dio get dio => _dio;

  // GET request
  Future<Response> get(
    String path, {
    Map<String, dynamic>? queryParameters,
    Options? options,
    CancelToken? cancelToken,
    ProgressCallback? onReceiveProgress,
  }) async {
    return await _dio.get(
      path,
      queryParameters: queryParameters,
      options: options,
      cancelToken: cancelToken,
      onReceiveProgress: onReceiveProgress,
    );
  }

  // POST request
  Future<Response> post(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Options? options,
    CancelToken? cancelToken,
    ProgressCallback? onSendProgress,
    ProgressCallback? onReceiveProgress,
    bool isWebRequest = false,
  }) async {
    Map<String, dynamic> bodyData = {};
    if (data is Map<String, dynamic>) {
      bodyData = data;
    }

    if (!isWebRequest) {
      bodyData = {"action": path, "data": data, "method": 'POST'};
    }

    bodyData = encryptTool.encryptJson(bodyData);

    final result = await _dio.post(
      path,
      data: bodyData,
      queryParameters: queryParameters,
      options: options,
      cancelToken: cancelToken,
      onSendProgress: onSendProgress,
      onReceiveProgress: onReceiveProgress,
    );

    var requestParams = data;
    var requestBody = bodyData;

    if (path.contains('/upload/base64')) {
      requestParams['fileData'] = "";
      requestBody['data'] = "";
      logLong('''
      iswebRequest: $isWebRequest,
      path: ${_dio.options.baseUrl}$path,
      POST request params: ${requestParams is Map<String, dynamic> ? jsonEncode(requestParams) : data},
      POST request bodyData: ${jsonEncode(requestBody)},
      response: ${jsonEncode(result.data)}''');
    } else if (path.contains('/device/upload')) {
      requestParams['data'] = "";
      requestBody['data'] = "";
      logLong('''
      iswebRequest: $isWebRequest,
      path: ${_dio.options.baseUrl}$path,
      POST request params: ${requestParams is Map<String, dynamic> ? jsonEncode(requestParams) : data},
      POST request bodyData: ${jsonEncode(requestBody)},
      response: ${jsonEncode(result.data)}''');
      // printToFile('device_upload', '''
      // iswebRequest: $isWebRequest,
      // path: ${_dio.options.baseUrl}$path,
      // POST request params: ${requestParams is Map<String, dynamic> ? jsonEncode(requestParams) : data},
      // POST request bodyData: ${jsonEncode(requestBody)},
      // response: ${jsonEncode(result.data)}''');
    } else {
      logLong('''
      iswebRequest: $isWebRequest,
      path: ${_dio.options.baseUrl}$path,
      POST request params: ${requestParams is Map<String, dynamic> ? jsonEncode(requestParams) : data},
      POST request bodyData: ${jsonEncode(requestBody)},
      response: ${jsonEncode(result.data)}''');
    }

    return result;
  }

  // PUT request
  Future<Response> put(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Options? options,
    CancelToken? cancelToken,
    ProgressCallback? onSendProgress,
    ProgressCallback? onReceiveProgress,
  }) async {
    return await _dio.put(
      path,
      data: data,
      queryParameters: queryParameters,
      options: options,
      cancelToken: cancelToken,
      onSendProgress: onSendProgress,
      onReceiveProgress: onReceiveProgress,
    );
  }

  // DELETE request
  Future<Response> delete(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Options? options,
    CancelToken? cancelToken,
  }) async {
    return await _dio.delete(
      path,
      data: data,
      queryParameters: queryParameters,
      options: options,
      cancelToken: cancelToken,
    );
  }

  // PATCH request
  Future<Response> patch(
    String path, {
    dynamic data,
    Map<String, dynamic>? queryParameters,
    Options? options,
    CancelToken? cancelToken,
    ProgressCallback? onSendProgress,
    ProgressCallback? onReceiveProgress,
  }) async {
    return await _dio.patch(
      path,
      data: data,
      queryParameters: queryParameters,
      options: options,
      cancelToken: cancelToken,
      onSendProgress: onSendProgress,
      onReceiveProgress: onReceiveProgress,
    );
  }
}
