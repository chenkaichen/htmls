enum ApiExceptionType {
  network,
  server,
  businessLogic,
  unexpected,
  timeout,
  unauthorized,
  forbidden,
  notFound,
  cancel,
}

class ApiException implements Exception {
  final ApiExceptionType type;
  final String message;
  final int? statusCode;
  final dynamic originalError;

  ApiException({
    required this.type,
    required this.message,
    this.statusCode,
    this.originalError,
  });

  @override
  String toString() {
    return 'ApiException(type: $type, message: $message, statusCode: $statusCode)';
  }
}
