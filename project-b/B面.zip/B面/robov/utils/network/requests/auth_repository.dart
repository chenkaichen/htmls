import 'dart:convert';

import 'package:app_tracking_transparency/app_tracking_transparency.dart';
import 'package:homewallet/core/app_public_constants.dart';
import 'package:dio/dio.dart';
import 'package:flutter/cupertino.dart';
import 'package:uuid/uuid.dart';
import '../../../models/start_model.dart';
import '../../../models/upload_image_response_model.dart';
import '../../hud/hud_tool.dart';
import '../base_repository.dart';
import '../exceptions/api_exception.dart';

class AuthRepository extends BaseRepository {
  Future<String> getRequestId({
    required Map<String, dynamic> paramsData,
  }) async {
    try {
      final result = await safeApiCall<String>(
        apiCall: () =>
            apiClient.post(RequestApiConstants.getRequestId, data: paramsData),
        onSuccess: (data) {
          if (data == null) return "";
          return data['requestId'] ?? "";
        },
      );

      return result ?? "";
    } on ApiException catch (e) {
      JCHUDTool.showToast(e.message);
      return "";
    }
  }

  Future<bool> updateDeviceInfo(String deviceInfo) async {
    try {
      final result = await safeApiCall<bool>(
        apiCall: () => apiClient.post(
          RequestApiConstants.uploadOrderDeviceInfo,
          data: {'tokenKey': Uuid().v4().toUpperCase(), 'data': deviceInfo},
        ),
        onSuccess: (data) {
          return true;
        },
      );

      return result ?? true;
    } on ApiException catch (e) {
      JCHUDTool.showToast(e.message);
      return false;
    }
  }

  Future<bool> deviceDetect() async {
    try {
      final result = await safeApiCall<bool>(
        apiCall: () =>
            apiClient.post(RequestApiConstants.deviceDetect, data: {}),
        onSuccess: (data) {
          if (data == null) return false;

          return data['isPrivateRelay'] ?? false;
        },
      );
      return result ?? false;
    } catch (e) {
      debugPrint('Error uploading track ID: $e');
      return false;
    }
  }

  // Request with Web
  Future<Map<dynamic, dynamic>> requestWithWeb(String params) async {
    try {
      final result = await safeApiCall<Map<dynamic, dynamic>>(
        apiCall: () => apiClient.post(
          "/requestWithWeb",
          data: jsonDecode(params),
          isWebRequest: true,
        ),
        onSuccess: (data) {
          return data;
        },
        isWebRequest: true,
      );

      return result ?? {};
    } on ApiException {
      return {};
    }
  }

  Future<StartModel?> startFirst() async {
    try {
      final result = await safeApiCall<StartModel>(
        apiCall: () => apiClient.post(RequestApiConstants.startFirst, data: {}),
        onSuccess: (data) {
          if (data == null) {
            return null;
          }
          return StartModel.fromJson(data);
        },
      );

      return result;
    } on ApiException catch (e) {
      JCHUDTool.showToast(e.message);
      return null;
    }
  }

  Future<bool> uploadAddressBook({
    required List<Map<String, dynamic>> list,
  }) async {
    try {
      final result = await safeApiCall<bool>(
        apiCall: () => apiClient.post(
          RequestApiConstants.addressBook,
          data: {'addressBook': list},
        ),
        onSuccess: (_) {
          return true;
        },
      );
      return result ?? false;
    } on ApiException catch (e) {
      JCHUDTool.showToast(e.message);
      return false;
    }
  }

  Future<bool> uploadAttStatus() async {
    try {
      final status = await AppTrackingTransparency.trackingAuthorizationStatus;

      final result = await safeApiCall<bool>(
        apiCall: () => apiClient.post(
          RequestApiConstants.attStatus,
          data: {'att': status.name},
        ),
        onSuccess: (data) {
          return true;
        },
      );
      return result ?? false;
    } catch (e) {
      debugPrint('Error uploading device info: $e');
      return false;
    }
  }

  Future<UploadImageResponseModel?> uploadImage({
    required String type,
    required String base64Image,
  }) async {
    try {
      final result = await safeApiCall<UploadImageResponseModel>(
        apiCall: () => apiClient.post(
          RequestApiConstants.uploadImage,
          data: {
            'type': type,
            'fileData': 'data:image/png;base64,$base64Image',
            'originalFileName': '${DateTime.now().millisecondsSinceEpoch}.png',
          },
          options: Options(extra: {'showLoading': true}),
        ),
        onSuccess: (data) {
          if (data == null) {
            throw ApiException(
              type: ApiExceptionType.notFound,
              message: 'Response data is null',
            );
          }

          debugPrint('uploadImage response: $data');

          if (data is String) {
            return UploadImageResponseModel(
              url: data,
              fileName: '${DateTime.now().millisecondsSinceEpoch}.png',
            );
          }

          return UploadImageResponseModel.fromJson(data);
        },
      );

      if (result == null) {
        throw ApiException(
          type: ApiExceptionType.notFound,
          message: 'Failed to parse upload image response',
        );
      }

      return result;
    } on ApiException catch (e) {
      JCHUDTool.showToast(e.message);
      return null;
    }
  }
}
