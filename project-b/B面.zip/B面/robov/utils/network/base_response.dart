import 'package:homewallet/core/app_public_constants.dart';

class BaseResponse<T> {
  final int code;
  final T? data;
  final String? msg;
  final bool success;
  final String? errorCode;

  BaseResponse({
    required this.code,
    this.data,
    this.msg,
    required this.success,
    this.errorCode,
  });

  factory BaseResponse.fromJson(
    Map<String, dynamic> json,
    T? Function(dynamic)? fromJsonT,
  ) {
    return BaseResponse<T>(
      code: json['code'] as int? ?? 0,
      data: fromJsonT != null ? fromJsonT(json['data']) : json['data'] as T?,
      msg: json['msg'] as String?,
      success: json['success'] as bool? ?? false,
      errorCode: json['errorCode'] as String?,
    );
  }

  Map<String, dynamic> toJson(Object? Function(T)? toJsonT) {
    return {
      'code': code,
      'data': data != null && toJsonT != null ? toJsonT(data as T) : data,
      'msg': msg,
      'success': success,
      'errorCode': errorCode,
    };
  }

  bool get isSuccess => code == RequestApiConstants.successCode;
}
