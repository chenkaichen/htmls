import 'dart:convert';
import 'dart:math';
import 'package:encrypt/encrypt.dart';
import 'package:pointycastle/asymmetric/api.dart';
import 'package:convert/convert.dart';
import 'package:homewallet/core/app_public_constants.dart';

class RequestEncryptTool {
  /// ⚠️ 固定 IV
  static final IV _iv = IV.fromUtf8('A-16-Byte-String');

  /// 生成 AES key（16字节）
  Key _generateKey() {
    // final rand = Random.secure();
    // final bytes = List<int>.generate(16, (_) => rand.nextInt(256));
    // return Key(Uint8List.fromList(bytes));

    const chars =
        'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';

    final rand = Random.secure();
    final str = List.generate(
      16,
      (_) => chars[rand.nextInt(chars.length)],
    ).join();
    return Key.fromUtf8(str);
  }

  /// AES 加密（HEX）
  Map<String, String> encryptJson(Map<String, dynamic> data) {
    final key = _generateKey();

    final jsonStr = jsonEncode(data);

    final encrypter = Encrypter(AES(key, mode: AESMode.cbc));
    final encrypted = encrypter.encrypt(jsonStr, iv: _iv);

    final encryptedKey = encryptKey(key);

    return {
      'data': hex.encode(encrypted.bytes).toUpperCase(),
      'id': encryptedKey,
    };
  }

  /// RSA 加密 key（HEX）
  String encryptKey(Key key) {
    final publicKey =
        RSAKeyParser().parse(AppPublicConstants.requestPublicKey)
            as RSAPublicKey;

    final encrypter = Encrypter(
      RSA(publicKey: publicKey, encoding: RSAEncoding.PKCS1),
    );
    final encrypted = encrypter.encryptBytes(key.bytes);

    return hex.encode(encrypted.bytes).toUpperCase();
  }
}
