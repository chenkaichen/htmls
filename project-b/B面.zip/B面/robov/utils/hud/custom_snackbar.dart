import 'package:flutter/material.dart';

import '../navigation/navigation_service.dart';

class CustomSnackbar {
  static OverlayEntry? _currentOverlay;

  static void show({
    required String message,
    SnackbarType type = SnackbarType.info,
    Duration duration = const Duration(seconds: 2),
  }) {
    final context = NavigationService.context!;

    _currentOverlay?.remove();

    final overlay = NavigationService.navigatorKey.currentState?.overlay;

    if (overlay == null) {
      debugPrint('Overlay not found');
      return;
    }

    final mediaQuery = MediaQuery.of(context);

    final entry = OverlayEntry(
      builder: (_) => Positioned(
        top: mediaQuery.size.height * 0.4,
        left: mediaQuery.size.width * 0.2,
        right: mediaQuery.size.width * 0.2,
        child: Material(
          color: Colors.transparent,
          child: AnimatedOpacity(
            opacity: 1,
            duration: Duration(milliseconds: 300),
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 24.0,
                vertical: 16.0,
              ),
              decoration: BoxDecoration(
                color: _getBackgroundColor(type),
                borderRadius: BorderRadius.circular(12.0),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.2),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ),
        ),
      ),
    );

    _currentOverlay = entry;

    overlay.insert(entry);

    Future.delayed(duration, () {
      if (_currentOverlay == entry) {
        entry.remove();
        _currentOverlay = null;
      }
    });
  }

  static Color _getBackgroundColor(SnackbarType type) {
    switch (type) {
      case SnackbarType.success:
        return Colors.green.withValues(alpha: 0.9);

      case SnackbarType.error:
        return Colors.red.withValues(alpha: 0.9);

      case SnackbarType.warning:
        return Colors.orange.withValues(alpha: 0.9);

      case SnackbarType.info:
        return Colors.grey.shade700.withValues(alpha: 0.9);
    }
  }

  static void success(String message) {
    show(message: message, type: SnackbarType.success);
  }

  static void error(String message) {
    show(message: message, type: SnackbarType.error);
  }

  static void warning(String message) {
    show(message: message, type: SnackbarType.warning);
  }

  static void info(String message) {
    show(message: message, type: SnackbarType.info);
  }
}

enum SnackbarType { success, error, warning, info }
