import 'dart:async';
import 'package:flutter/material.dart';
import '../navigation/navigation_service.dart';

class JCHUDTool {
  JCHUDTool._();

  static OverlayEntry? _loadingEntry;

  static OverlayEntry? _toastEntry;

  static int _loadingCount = 0;

  static String _loadingText = "Đang tải...";

  static bool get isLoading => _loadingEntry != null;

  /// =========================
  /// Loading
  /// =========================
  static void showLoading({String? text}) {
    _loadingCount++;

    debugPrint("showLoading count=$_loadingCount");

    _loadingText = text ?? "Đang tải...";

    if (_loadingEntry != null) {
      _loadingEntry?.markNeedsBuild();
      return;
    }

    final overlay = NavigationService.overlayKey.currentState;

    if (overlay == null) {
      debugPrint("overlay is null");
      return;
    }

    _loadingEntry = OverlayEntry(
      builder: (_) => _LoadingWidget(text: _loadingText),
    );

    overlay.insert(_loadingEntry!);
  }

  /// =========================
  /// Dismiss Loading
  /// =========================
  static void dismissLoading() {
    if (_loadingCount <= 0) {
      _loadingCount = 0;
      return;
    }

    _loadingCount--;

    debugPrint("dismissLoading count=$_loadingCount");

    if (_loadingCount > 0) {
      return;
    }

    _loadingCount = 0;

    try {
      _loadingEntry?.remove();
    } catch (_) {}

    _loadingEntry = null;
  }

  /// =========================
  /// Force Dismiss
  /// =========================
  static void dismissAll() {
    _loadingCount = 0;
    try {
      _loadingEntry?.remove();
    } catch (_) {}
    _loadingEntry = null;

    _toastEntry?.remove();
    _toastEntry = null;
  }

  /// =========================
  /// Toast
  /// =========================

  static String? _lastToast;

  static Timer? _toastTimer;

  static void showToast(
    String text, {
    Duration duration = const Duration(seconds: 2),
  }) {
    if (_lastToast == text) return;

    _lastToast = text;

    _toastTimer?.cancel();

    _toastEntry?.remove();

    final overlay = NavigationService.overlayKey.currentState;

    if (overlay == null) return;

    _toastEntry = OverlayEntry(
      builder: (_) {
        return Center(
          child: SafeArea(
            child: Material(
              color: Colors.transparent,
              child: Center(
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 44),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 16,
                    vertical: 12,
                  ),
                  decoration: BoxDecoration(
                    color: Colors.black.withValues(alpha: 0.85),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    text,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Colors.white),
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );

    overlay.insert(_toastEntry!);

    _toastTimer = Timer(duration, () {
      _toastEntry?.remove();
      _toastEntry = null;
      _lastToast = null;
    });
  }

  /// =========================
  /// Confirm Dialog
  /// =========================
  static Future<bool> _showConfirm({
    String title = "Lưu ý",
    String content = "",
    String cancelText = "Hủy",
    String confirmText = "Xác nhận",
    bool barrierDismissible = true,
  }) async {
    final context = NavigationService.context;

    if (context == null) {
      return false;
    }

    final result = await showDialog<bool>(
      context: context,
      barrierDismissible: barrierDismissible,
      builder: (_) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          title: Text(title),
          content: Text(content),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: Text(cancelText),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: Text(confirmText),
            ),
          ],
        );
      },
    );

    return result ?? false;
  }

  /// =========================
  /// Native Confirm Dialog
  /// =========================
  static Future<bool> showConfirm({
    String title = "Lưu ý",
    String content = "",
    String cancelText = "Hủy",
    String confirmText = "Xác nhận",
    bool barrierDismissible = true,
    bool destructive = false,
  }) async {
    final context = NavigationService.context;

    if (context == null) {
      return false;
    }

    // final isIOS = Theme.of(context).platform == TargetPlatform.iOS;

    // if (isIOS) {
    //   final result = await showCupertinoDialog<bool>(
    //     context: context,
    //     barrierDismissible: barrierDismissible,
    //     builder: (_) {
    //       return CupertinoAlertDialog(
    //         title: title.isEmpty ? null : Text(title),
    //         content: content.isEmpty
    //             ? null
    //             : Padding(
    //                 padding: const EdgeInsets.only(top: 8),
    //                 child: Text(content),
    //               ),
    //         actions: [
    //           CupertinoDialogAction(
    //             onPressed: () {
    //               Navigator.pop(context, false);
    //             },
    //             child: Text(cancelText),
    //           ),
    //           CupertinoDialogAction(
    //             isDefaultAction: !destructive,
    //             isDestructiveAction: destructive,
    //             onPressed: () {
    //               Navigator.pop(context, true);
    //             },
    //             child: Text(confirmText),
    //           ),
    //         ],
    //       );
    //     },
    //   );

    //   return result ?? false;
    // }

    return _showConfirm(
      title: title,
      content: content,
      cancelText: cancelText,
      confirmText: confirmText,
      barrierDismissible: barrierDismissible,
    );
  }
}

/// =========================
/// Loading Widget
/// =========================
class _LoadingWidget extends StatelessWidget {
  final String text;

  const _LoadingWidget({required this.text});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.black.withValues(alpha: 0.15),
      child: Center(
        child: Container(
          constraints: const BoxConstraints(minWidth: 120),
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          decoration: BoxDecoration(
            color: Colors.black87,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const SizedBox(
                width: 28,
                height: 28,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  color: Colors.white,
                ),
              ),
              if (text.isNotEmpty) ...[
                const SizedBox(height: 14),
                Text(
                  text,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                  textAlign: TextAlign.center,
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }
}
