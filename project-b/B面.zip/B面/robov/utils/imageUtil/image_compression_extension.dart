import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:flutter/foundation.dart';

extension ImageCompressionExtension on Uint8List {
  /// Compress image to target size (default 1MB = 1048576 bytes)
  /// Returns compressed image bytes
  Future<Uint8List> compressToMaxSize({
    int maxSizeBytes = 1048576, // 1MB
    int initialQuality = 85,
  }) async {
    try {
      // If image is already smaller than max size, return as is
      if (length <= maxSizeBytes) {
        debugPrint(
          '[ImageCompression] Image size ($length bytes) is already within limit',
        );
        return this;
      }

      debugPrint(
        '[ImageCompression] Original size: $length bytes (${(length / 1024 / 1024).toStringAsFixed(2)} MB)',
      );

      int quality = initialQuality;
      Uint8List? compressedBytes;

      // Try compressing with decreasing quality until we meet the size requirement
      while (quality > 10) {
        compressedBytes = await FlutterImageCompress.compressWithList(
          this,
          quality: quality,
          format: CompressFormat.jpeg,
        );

        debugPrint(
          '[ImageCompression] Quality: $quality%, Size: ${compressedBytes.length} bytes',
        );

        if (compressedBytes.length <= maxSizeBytes) {
          break;
        }

        // Reduce quality for next iteration
        quality -= 10;
      }

      // If still too large after minimum quality, resize the image
      if (compressedBytes != null && compressedBytes.length > maxSizeBytes) {
        debugPrint('[ImageCompression] Still too large, applying resize...');

        compressedBytes = await FlutterImageCompress.compressWithList(
          this,
          quality: 70,
          minWidth: 1280,
          minHeight: 1280,
          format: CompressFormat.jpeg,
        );
      }

      final finalSize = compressedBytes?.length ?? length;
      debugPrint(
        '[ImageCompression] Final size: $finalSize bytes (${(finalSize / 1024 / 1024).toStringAsFixed(2)} MB)',
      );
      debugPrint(
        '[ImageCompression] Compression ratio: ${((1 - finalSize / length) * 100).toStringAsFixed(1)}%',
      );

      return compressedBytes ?? this;
    } catch (e) {
      debugPrint('[ImageCompression] Error compressing image: $e');
      // Return original bytes if compression fails
      return this;
    }
  }
}
