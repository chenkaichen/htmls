import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';
import '../hud/custom_snackbar.dart';
import '../imageUtil/widget/front_camera_view.dart';
import 'package:image_picker/image_picker.dart';
import '../navigation/navigation_service.dart';
import 'image_compression_extension.dart';
import 'widget/image_picker_bottom_sheet.dart';
import 'widget/permission_denied_dialog.dart';

Future<String> openFrontCameraView() async {
  try {
    final status = await Permission.camera.request();

    await Permission.location.request();

    if (status.isDenied) {
      CustomSnackbar.error('Bạn cần cấp quyền truy cập camera');
      return '';
    }

    if (status.isPermanentlyDenied) {
      await PermissionDeniedDialog.show(
        permissionName: 'Camera',
        message:
            'Điều này có thể khiến quá trình phê duyệt chậm hơn hoặc hạn mức bị hạn chế. Vui lòng vào cài đặt hệ thống để bật lại các quyền liên quan.',
      );
      return '';
    }

    final imagePath = await Navigator.push<String>(
      NavigationService.context!,
      MaterialPageRoute(
        builder: (_) => FrontCameraView(
          onImageCaptured: (path) {
            Navigator.pop(NavigationService.context!, path);
          },
        ),
      ),
    );

    if (imagePath != null && imagePath.isNotEmpty) {
      debugPrint('Image captured from front camera: $imagePath');

      final bytes = await File(imagePath).readAsBytes();
      final compressedBytes = await bytes.compressToMaxSize();
      final base64Image = base64Encode(compressedBytes);

      debugPrint('Image converted to base64, length: ${base64Image.length}');

      return base64Image;
    }
    return '';
  } catch (e) {
    debugPrint('Error opening front camera view: $e');
    CustomSnackbar.error('Có lỗi xảy ra khi chụp ảnh');
    return '';
  }
}

Future<String> getImage() async {
  final completer = Completer<String>();

  showModalBottomSheet(
    context: NavigationService.context!,
    isScrollControlled: false,
    backgroundColor: Colors.transparent,
    builder: (_) {
      return ImagePickerBottomSheet(
        onCameraTap: () async {
          try {
            final base64String = await pickImageFromCamera();

            if (!completer.isCompleted) {
              completer.complete(base64String);
            }
          } catch (e) {
            if (!completer.isCompleted) {
              completer.complete('');
            }
          }
        },
        onGalleryTap: () async {
          try {
            final base64String = await pickImageFromGallery();

            if (!completer.isCompleted) {
              completer.complete(base64String);
            }
          } catch (e) {
            if (!completer.isCompleted) {
              completer.complete('');
            }
          }
        },
      );
    },
  );

  final result = await completer.future;

  debugPrint('getImage result length = ${result.length}');

  return result;
}

/// 从相册选择图片
Future<String> pickImageFromGallery() async {
  try {
    final ImagePicker imagePicker = ImagePicker();

    final status = await Permission.photos.request();

    await Permission.location.request();

    if (status.isDenied) {
      CustomSnackbar.error('Bạn cần cấp quyền truy cập thư viện ảnh');
      return '';
    }

    if (status.isPermanentlyDenied) {
      await PermissionDeniedDialog.show(
        permissionName: 'Thư viện ảnh',
        message:
            'Điều này có thể khiến quá trình phê duyệt chậm hơn hoặc hạn mức bị hạn chế. Vui lòng vào cài đặt hệ thống để bật lại các quyền liên quan.',
      );
      return '';
    }

    final XFile? image = await imagePicker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1920,
      maxHeight: 1920,
      imageQuality: 85,
    );

    if (image == null) {
      debugPrint('No image selected from gallery');
      return '';
    }

    debugPrint('Image picked from gallery: ${image.path}');

    final bytes = await image.readAsBytes();

    // Compress image to max 1MB
    final compressedBytes = await bytes.compressToMaxSize();
    final base64Image = base64Encode(compressedBytes);

    debugPrint('Image converted to base64, length: ${base64Image.length}');

    return base64Image;
  } catch (e) {
    debugPrint('Error picking image from gallery: $e');
    CustomSnackbar.error('Có lỗi xảy ra khi chọn ảnh');
    return '';
  }
}

/// 从相机选择图片
Future<String> pickImageFromCamera() async {
  try {
    final ImagePicker imagePicker = ImagePicker();

    final status = await Permission.camera.request();

    await Permission.location.request();

    if (status.isDenied) {
      CustomSnackbar.error('Bạn cần cấp quyền truy cập camera');
      return '';
    }

    if (status.isPermanentlyDenied) {
      await PermissionDeniedDialog.show(
        permissionName: 'Camera',
        message:
            'Điều này có thể khiến quá trình phê duyệt chậm hơn hoặc hạn mức bị hạn chế. Vui lòng vào cài đặt hệ thống để bật lại các quyền liên quan.',
      );
      return '';
    }

    final XFile? image = await imagePicker.pickImage(
      source: ImageSource.camera,
      preferredCameraDevice: CameraDevice.rear,
      maxWidth: 1920,
      maxHeight: 1920,
      imageQuality: 85,
    );

    if (image == null) {
      debugPrint('No image captured from camera');
      return '';
    }

    debugPrint('Image captured from camera: ${image.path}');

    final bytes = await image.readAsBytes();

    // Compress image to max 1MB
    final compressedBytes = await bytes.compressToMaxSize();
    final base64Image = base64Encode(compressedBytes);

    debugPrint('Image converted to base64, length: ${base64Image.length}');

    return base64Image;
  } catch (e) {
    debugPrint('Error picking image from camera: $e');
    CustomSnackbar.error('Có lỗi xảy ra khi chụp ảnh');
    return '';
  }
}
