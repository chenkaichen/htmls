import 'dart:ui';

import 'package:homewallet/core/app_public_constants.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';

const deviceChannel = MethodChannel('flutter_native_channel');

Future<Map<String, dynamic>> loginFirst() async {
  var result = <String, dynamic>{};

  final locale = PlatformDispatcher.instance.locale;

  /// 设备当前语言
  result['language'] = locale.languageCode;

  /// 设备当前国家码
  result['countryCode'] = locale.countryCode;

  final iosInfo = await DeviceInfoPlugin().iosInfo;
  String osVersion = iosInfo.systemVersion;
  String idfv = iosInfo.identifierForVendor ?? '';
  String deviceName = iosInfo.name;

  /// 设备当前版本号
  result['osVersion'] = osVersion;

  /// IDFV 设备唯一标识
  result['idfv'] = idfv;

  /// 设备名称
  result['deviceName'] = deviceName;

  final now = DateTime.now();
  final timezoneOffset = now.timeZoneOffset.inHours;

  /// 设备当前时区
  result['timezoneOffset'] = timezoneOffset;

  /// 当前版本号
  result["appVersion"] = AppPublicConstants.appFullVersion;

  /// 应 用 列 表
  result['haves'] = await _getHavesFromeNative();

  /// 单词列表
  result['words'] = await _getWords();

  return result;
}

/// 从原生获取iOS部分设备信息
Future<Map<String, dynamic>> _getHavesFromeNative() async {
  try {
    final result = await deviceChannel.invokeMethod<Map<dynamic, dynamic>>(
      'getHaves',
    );
    final map = Map<String, dynamic>.from(result ?? {});

    return map;
  } catch (e) {
    debugPrint('Error: $e');
    // 处理异常
    return {};
  }
}

/// 从原生获取iOS部分设备信息
Future<Map<String, dynamic>> _getWords() async {
  try {
    final result = await deviceChannel.invokeMethod<Map<dynamic, dynamic>>(
      'getWords',
    );
    final map = Map<String, dynamic>.from(result ?? {});

    return map;
  } catch (e) {
    debugPrint('Error: $e');
    // 处理异常
    return {};
  }
}
