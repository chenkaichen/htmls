import 'package:flutter/cupertino.dart';

class NavigationService {
  static final GlobalKey<NavigatorState> navigatorKey =
      GlobalKey<NavigatorState>();
  static final GlobalKey<OverlayState> overlayKey = GlobalKey<OverlayState>();

  static BuildContext? get context => navigatorKey.currentContext;

  static Future<T?> push<T extends Object?>(Widget newPage) {
    return navigatorKey.currentState!.push<T>(
      CupertinoPageRoute(builder: (_) => newPage),
    );
  }

  static Future<T?> pushReplacement<T extends Object?, TO extends Object?>(
    Widget newPage, {
    TO? result,
  }) {
    return navigatorKey.currentState!.pushReplacement<T, TO?>(
      CupertinoPageRoute(builder: (_) => newPage),
      result: result,
    );
  }

  static Future pushNamedAndRemoveUntil<T>(
    String routeName, {
    Object? arguments,
  }) {
    return navigatorKey.currentState!.pushNamedAndRemoveUntil(
      routeName,
      arguments: arguments,
      (route) => false,
    );
  }

  static Future pushAndRemoveUntil(PageRoute route) {
    return navigatorKey.currentState!.pushAndRemoveUntil(
      route,
      (route) => false,
    );
  }

  static Future pushReplacementNamed(String routeName) {
    return navigatorKey.currentState!.pushReplacementNamed(routeName);
  }

  static void pop<T>([T? result]) {
    navigatorKey.currentState?.pop(result);
  }

  static void popUntil(String routeName) {
    navigatorKey.currentState?.popUntil(ModalRoute.withName(routeName));
  }
}
