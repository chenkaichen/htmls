import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'navigation_service.dart';

// ignore: non_constant_identifier_names
AppBar CustomNavigationBar({
  required String title,
  bool showBackButton = true,
  Color? backgroundColor,
  Color? backButtonColor,
  Color? titleColor,
  List<Widget>? actions,
  SystemUiOverlayStyle? statusBarStyle,
  VoidCallback? onBackPressed,
}) {
  return AppBar(
    centerTitle: true,
    backgroundColor: backgroundColor ?? const Color(0xFF1F62E3),
    systemOverlayStyle:
        statusBarStyle ?? SystemUiOverlayStyle.light, // 深色状态栏（适配浅色背景）
    title: Text(
      title,
      maxLines: 1,
      style: TextStyle(
        color: titleColor ?? CupertinoColors.white,
        fontSize: 18,
        fontWeight: FontWeight.w700,
      ),
    ),
    automaticallyImplyLeading: false,
    leading: showBackButton
        ? CupertinoNavigationBarBackButton(
            color: backButtonColor ?? CupertinoColors.white,
            onPressed:
                onBackPressed ??
                () {
                  NavigationService.pop();
                },
          )
        : null,
    actions: actions,
  );
}
