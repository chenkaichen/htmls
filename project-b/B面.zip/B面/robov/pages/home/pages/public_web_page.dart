import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:homewallet/core/app_public_constants.dart';
import 'package:homewallet/features/auth/data/auth_session_store.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_flutter_wkwebview/webview_flutter_wkwebview.dart';

import '../controllers/public_web_controller.dart';

class PublicWebPage extends StatefulWidget {
  const PublicWebPage({super.key});

  @override
  State<PublicWebPage> createState() => _PublicWebPageState();
}

class _PublicWebPageState extends State<PublicWebPage> {
  WebViewController? _webViewController;
  PublicWebController? _controller;

  bool _isInitializing = true;

  @override
  void initState() {
    super.initState();

    unawaited(_initialize());
  }

  Future<void> _initialize() async {
    try {
      debugPrint('[PublicWebPage] Starting initialization...');

      // 1. 读取登录态
      final sessionStore = SecureAuthSessionStore();
      final session = await sessionStore.read();

      final token = session?.token ?? '';
      final userId = session?.userId;

      debugPrint(
        '[PublicWebPage] Session loaded: '
        'userId=$userId, hasToken=${token.isNotEmpty}',
      );

      // 2. 创建 H5 URL
      final url = _buildUrl(token);

      debugPrint('[PublicWebPage] H5 URL created');

      // 3. 创建业务 Controller
      _controller = PublicWebController(initialUrl: url);

      // 4. 清理旧 Cookie
      await _clearAllWebViewData();

      // 5. 设置 user_id Cookie
      if (userId != null) {
        await _setUserIdCookie(userId: userId, url: url);
      } else {
        debugPrint('[PublicWebPage] User ID is null, skipping cookie');
      }

      // 6. 创建 WebView
      await _createWebView(url);

      if (!mounted) {
        return;
      }

      setState(() {
        _isInitializing = false;
      });

      debugPrint('[PublicWebPage] Initialization completed');
    } catch (e, stackTrace) {
      debugPrint('[PublicWebPage] Initialization error: $e');
      debugPrint('$stackTrace');

      if (!mounted) {
        return;
      }

      setState(() {
        _isInitializing = false;
      });
    }
  }

  String _buildUrl(String token) {
    final encodedToken = Uri.encodeComponent(token);

    return '${AppPublicConstants.otherBaseUrl}'
        '/#/home/index'
        '?isBweb=1'
        '&token=$encodedToken'
        '&package=${Uri.encodeComponent(AppPublicConstants.appName.toLowerCase())}'
        '&isAppLogin=1';
  }

  Future<void> _createWebView(String url) async {
    final PlatformWebViewControllerCreationParams params;

    if (WebViewPlatform.instance is WebKitWebViewPlatform) {
      debugPrint('[PublicWebPage] Using WKWebView configuration');

      params = WebKitWebViewControllerCreationParams(
        allowsInlineMediaPlayback: true,
        mediaTypesRequiringUserAction: const <PlaybackMediaTypes>{},
      );
    } else {
      params = const PlatformWebViewControllerCreationParams();
    }

    final controller = WebViewController.fromPlatformCreationParams(params)
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setNavigationDelegate(_buildNavigationDelegate());

    if (controller.platform is WebKitWebViewController) {
      final wkController = controller.platform as WebKitWebViewController;

      await wkController.setAllowsBackForwardNavigationGestures(false);

      debugPrint('[PublicWebPage] WKWebView features configured');
    }

    _webViewController = controller;

    _controller?.setWebViewController(controller);

    if (mounted) {
      setState(() {});
    }

    debugPrint('[PublicWebPage] Loading URL...');

    await controller.loadRequest(Uri.parse(url));
  }

  NavigationDelegate _buildNavigationDelegate() {
    return NavigationDelegate(
      onPageStarted: (url) {
        debugPrint('[PublicWebPage] Page started: $url');

        _controller?.onPageStarted(url);
      },

      onPageFinished: (url) {
        debugPrint('[PublicWebPage] Page finished: $url');

        _controller?.onPageFinished(url);
        if (mounted) {
          setState(() {});
        }
      },

      onWebResourceError: (error) {
        debugPrint(
          '[PublicWebPage] Web resource error: '
          '${error.errorCode} ${error.description}',
        );

        _controller?.onPageError(error);
      },

      onProgress: (progress) {
        debugPrint('[PublicWebPage] Progress: $progress%');
      },

      onNavigationRequest: (request) {
        try {
          final url = request.url;

          debugPrint('[PublicWebPage] Navigation request: $url');

          if (!mounted) {
            return NavigationDecision.prevent;
          }

          if (url.startsWith('callfunction://')) {
            debugPrint('[PublicWebPage] iOS callback detected: $url');

            _controller?.handleIOSCallback(url);

            return NavigationDecision.prevent;
          }
        } catch (e) {
          debugPrint('[PublicWebPage] Navigation error: $e');
        }

        return NavigationDecision.navigate;
      },
    );
  }

  Future<void> _clearAllWebViewData() async {
    try {
      debugPrint('[PublicWebPage] Clearing WebView cookies...');

      final cookieManager = WebViewCookieManager();

      await cookieManager.clearCookies();

      debugPrint('[PublicWebPage] ✓ Cookies cleared');
    } catch (e) {
      debugPrint('[PublicWebPage] Clear WebView data error: $e');
    }
  }

  Future<void> _setUserIdCookie({
    required dynamic userId,
    required String url,
  }) async {
    try {
      final uri = Uri.parse(url);
      final domain = uri.host;

      if (domain.isEmpty) {
        debugPrint('[PublicWebPage] Invalid cookie domain');
        return;
      }

      final cookieManager = WebViewCookieManager();

      await cookieManager.setCookie(
        WebViewCookie(
          name: 'user_id',
          value: userId.toString(),
          domain: domain,
          path: '/',
        ),
      );

      debugPrint(
        '[PublicWebPage] ✓ Cookie set: '
        'user_id=$userId, domain=$domain',
      );
    } catch (e) {
      debugPrint('[PublicWebPage] Set cookie error: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final isLoading =
        _isInitializing ||
        _webViewController == null ||
        (_controller?.isLoading ?? false);

    return CupertinoPageScaffold(
      child: SafeArea(
        child: Stack(
          children: [
            if (_webViewController != null)
              WebViewWidget(controller: _webViewController!),

            if (isLoading)
              const ColoredBox(
                color: Colors.white,
                child: Center(child: CircularProgressIndicator()),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _webViewController = null;
    _controller = null;

    super.dispose();
  }
}
