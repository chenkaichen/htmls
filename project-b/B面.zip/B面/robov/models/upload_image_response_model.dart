class UploadImageResponseModel {
  final String url;
  final String fileName;
  final ImageOcrModel? ocr;

  UploadImageResponseModel({
    required this.url,
    required this.fileName,
    this.ocr,
  });

  factory UploadImageResponseModel.fromJson(Map<String, dynamic> json) {
    return UploadImageResponseModel(
      url: json['url'] as String,
      fileName: json['fileName'] as String,
      ocr: json['ocr'] == null
          ? null
          : ImageOcrModel.fromJson(json['ocr'] as Map<String, dynamic>),
    );
  }
}

class ImageOcrModel {
  final bool ocrSuccess;
  final String name;
  // ignore: non_constant_identifier_names
  final String IDcard;
  final String gender;
  final String birthday;

  ImageOcrModel({
    required this.ocrSuccess,
    required this.name,
    // ignore: non_constant_identifier_names
    required this.IDcard,
    required this.gender,
    required this.birthday,
  });

  factory ImageOcrModel.fromJson(Map<String, dynamic> json) {
    return ImageOcrModel(
      ocrSuccess: json['ocrSuccess'] as bool,
      name: json['name'] as String,
      // ignore: non_constant_identifier_names
      IDcard: json['IDcard'] as String,
      gender: json['gender'] as String,
      birthday: json['birthday'] as String,
    );
  }
}
