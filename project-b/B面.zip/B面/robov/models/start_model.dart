class StartModel {
  String? appMark;
  String? name;
  String? icon;
  String? email;
  String? servicePhone;
  String? aboutContent;
  String? privacyUrl;
  String? mainLoginMode;
  List<dynamic>? otherLoginMode;
  bool? phoneLoginEnabled;

  StartModel({
    this.appMark,
    this.name,
    this.icon,
    this.email,
    this.servicePhone,
    this.aboutContent,
    this.privacyUrl,
    this.mainLoginMode,
    this.otherLoginMode,
    this.phoneLoginEnabled,
  });

  factory StartModel.fromJson(Map<String, dynamic> json) {
    return StartModel(
      appMark: json['appMark'],
      name: json['name'],
      icon: json['icon'],
      email: json['email'],
      servicePhone: json['servicePhone'],
      aboutContent: json['aboutContent'],
      privacyUrl: json['privacyUrl'],
      mainLoginMode: json['mainLoginMode'],
      otherLoginMode: json['otherLoginMode'],
      phoneLoginEnabled: json['phoneLoginEnabled'],
    );
  }
}
