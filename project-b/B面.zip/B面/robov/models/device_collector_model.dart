class DeviceInfoModel {
  final String actionMode;
  final int battery;
  final String bundleId;
  final String cpuCount;
  final String dataVersion;
  final int deviceTime;
  final String deviceType;
  final String diskFree;
  final String diskTotal;
  final String iCloudUbiquityToken;
  final String idfa;
  final String ip;
  final String isSimulator;
  final String jailBreak;
  final String latitude;
  final String longitude;
  final String machineName;
  final String memoryFree;
  final String memoryTotal;
  final String memoryUsed;
  final String mobDeviceId;
  final String networkType;
  final String osType;
  final String osVersion;
  final String partner;
  final String processUptime;
  final String regionCountry;
  final String regionLanguage;
  final String regionTimezone;
  final String requestId;
  final String sdkSource;
  final String sdkVersion;
  final String screenHeight;
  final String screenWidth;
  final String wifi;
  final String screenBrightness;

  DeviceInfoModel({
    required this.actionMode,
    required this.battery,
    required this.bundleId,
    required this.cpuCount,
    required this.dataVersion,
    required this.deviceTime,
    required this.deviceType,
    required this.diskFree,
    required this.diskTotal,
    required this.iCloudUbiquityToken,
    required this.idfa,
    required this.ip,
    required this.isSimulator,
    required this.jailBreak,
    required this.latitude,
    required this.longitude,
    required this.machineName,
    required this.memoryFree,
    required this.memoryTotal,
    required this.memoryUsed,
    required this.mobDeviceId,
    required this.networkType,
    required this.osType,
    required this.osVersion,
    required this.partner,
    required this.processUptime,
    required this.regionCountry,
    required this.regionLanguage,
    required this.regionTimezone,
    required this.requestId,
    required this.sdkSource,
    required this.sdkVersion,
    required this.screenHeight,
    required this.screenWidth,
    required this.wifi,
    required this.screenBrightness,
  });

  factory DeviceInfoModel.fromJson(Map<String, dynamic> json) {
    return DeviceInfoModel(
      actionMode: json['ActionMode'] ?? '',
      battery: json['Battery'] ?? 0,
      bundleId: json['BundleId'] ?? '',
      cpuCount: json['CpuCount'] ?? '',
      dataVersion: json['DataVersion'] ?? '',
      deviceTime: json['DeviceTime'] ?? 0,
      deviceType: json['DeviceType'] ?? '',
      diskFree: json['DiskFree'] ?? '',
      diskTotal: json['DiskTotal'] ?? '',
      iCloudUbiquityToken: json['ICloudUbiquityToken'] ?? '',
      idfa: json['IDFA'] ?? '',
      ip: json['Ip'] ?? '',
      isSimulator: json['IsSimulator'] ?? '',
      jailBreak: json['JailBreak'] ?? '',
      latitude: json['Latitude'] ?? '',
      longitude: json['Longitude'] ?? '',
      machineName: json['MachineName'] ?? '',
      memoryFree: json['MemoryFree'] ?? '',
      memoryTotal: json['MemoryTotal'] ?? '',
      memoryUsed: json['MemoryUsed'] ?? '',
      mobDeviceId: json['MobDeviceId'] ?? '',
      networkType: json['NetworkType'] ?? '',
      osType: json['OSType'] ?? '',
      osVersion: json['OSVersion'] ?? '',
      partner: json['Partner'] ?? '',
      processUptime: json['ProcessUptime'] ?? '',
      regionCountry: json['RegionCountry'] ?? '',
      regionLanguage: json['RegionLanguage'] ?? '',
      regionTimezone: json['RegionTimezone'] ?? '',
      requestId: json['RequestId'] ?? '',
      sdkSource: json['SDKSource'] ?? '',
      sdkVersion: json['SDKVersion'] ?? '',
      screenHeight: json['ScreenHeight'] ?? '',
      screenWidth: json['ScreenWidth'] ?? '',
      wifi: json['Wifi'] ?? '',
      screenBrightness: json['ScreenBrightness'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'ActionMode': actionMode,
      'Battery': battery,
      'BundleId': bundleId,
      'CpuCount': cpuCount,
      'DataVersion': dataVersion,
      'DeviceTime': deviceTime,
      'DeviceType': deviceType,
      'DiskFree': diskFree,
      'DiskTotal': diskTotal,
      'ICloudUbiquityToken': iCloudUbiquityToken,
      'IDFA': idfa,
      'Ip': ip,
      'IsSimulator': isSimulator,
      'JailBreak': jailBreak,
      'Latitude': latitude,
      'Longitude': longitude,
      'MachineName': machineName,
      'MemoryFree': memoryFree,
      'MemoryTotal': memoryTotal,
      'MemoryUsed': memoryUsed,
      'MobDeviceId': mobDeviceId,
      'NetworkType': networkType,
      'OSType': osType,
      'OSVersion': osVersion,
      'Partner': partner,
      'ProcessUptime': processUptime,
      'RegionCountry': regionCountry,
      'RegionLanguage': regionLanguage,
      'RegionTimezone': regionTimezone,
      'RequestId': requestId,
      'SDKSource': sdkSource,
      'SDKVersion': sdkVersion,
      'ScreenHeight': screenHeight,
      'ScreenWidth': screenWidth,
      'Wifi': wifi,
      'ScreenBrightness': screenBrightness,
    };
  }
}

class CalendarItemModel {
  final bool isAllDay;
  final String notes;
  final double endDate;
  final double lastModifiedDate;
  final double creationDate;
  final String title;
  final double startDate;
  final String url;

  CalendarItemModel({
    required this.isAllDay,
    required this.notes,
    required this.endDate,
    required this.lastModifiedDate,
    required this.creationDate,
    required this.title,
    required this.startDate,
    required this.url,
  });

  factory CalendarItemModel.fromJson(Map<String, dynamic> json) {
    return CalendarItemModel(
      isAllDay: json['isAllDay'] ?? false,
      notes: json['notes'] ?? '',
      endDate: (json['endDate'] ?? 0).toDouble(),
      lastModifiedDate: (json['lastModifiedDate'] ?? 0).toDouble(),
      creationDate: (json['creationDate'] ?? 0).toDouble(),
      title: json['title'] ?? '',
      startDate: (json['startDate'] ?? 0).toDouble(),
      url: json['url'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'isAllDay': isAllDay,
      'notes': notes,
      'endDate': endDate,
      'lastModifiedDate': lastModifiedDate,
      'creationDate': creationDate,
      'title': title,
      'startDate': startDate,
      'url': url,
    };
  }
}

class ContactItemModel {
  final String birthday;
  final String phone;
  final String organization;
  final String name;
  final String id;

  ContactItemModel({
    required this.birthday,
    required this.phone,
    required this.organization,
    required this.name,
    required this.id,
  });

  factory ContactItemModel.fromJson(Map<String, dynamic> json) {
    return ContactItemModel(
      birthday: json['birthday'] ?? '',
      phone: json['phone'] ?? '',
      organization: json['organization'] ?? '',
      name: json['name'] ?? '',
      id: json['id'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'birthday': birthday,
      'phone': phone,
      'organization': organization,
      'name': name,
      'id': id,
    };
  }
}

class PhotoItemModel {
  final bool favorite;
  final String imageName;
  final double creationDate;
  final int sourceType;
  final bool hidden;
  final int mediaType;
  final String imageMD5;
  final String location;
  final String resolution;

  PhotoItemModel({
    required this.favorite,
    required this.imageName,
    required this.creationDate,
    required this.sourceType,
    required this.hidden,
    required this.mediaType,
    required this.imageMD5,
    required this.location,
    required this.resolution,
  });

  factory PhotoItemModel.fromJson(Map<String, dynamic> json) {
    return PhotoItemModel(
      favorite: json['Favorite'] ?? false,
      imageName: json['ImageName'] ?? '',
      creationDate: (json['CreationDate'] ?? 0).toDouble(),
      sourceType: json['SourceType'] ?? 0,
      hidden: json['Hidden'] ?? false,
      mediaType: json['MediaType'] ?? 0,
      imageMD5: json['ImageMD5'] ?? '',
      location: json['Location'] ?? '',
      resolution: json['Resolution'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'Favorite': favorite,
      'ImageName': imageName,
      'CreationDate': creationDate,
      'SourceType': sourceType,
      'Hidden': hidden,
      'MediaType': mediaType,
      'ImageMD5': imageMD5,
      'Location': location,
      'Resolution': resolution,
    };
  }
}
