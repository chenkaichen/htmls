import 'package:shared_preferences/shared_preferences.dart';

class StorageService {
  // 单例实例
  static final StorageService _instance = StorageService._internal();

  // 工厂构造函数返回单例
  factory StorageService() {
    return _instance;
  }

  // 私有构造函数
  StorageService._internal();

  // SharedPreferences 实例
  late SharedPreferences _prefs;

  // 是否已初始化
  bool _isInitialized = false;

  // 初始化方法
  Future<StorageService> init() async {
    if (!_isInitialized) {
      _prefs = await SharedPreferences.getInstance();
      _isInitialized = true;
    }
    return this;
  }

  Future<void> setPermissionGranted(bool granted) async {
    await _prefs.setBool(_permissionGrantedKey, granted);
  }

  bool getPermissionGranted() {
    return _prefs.getBool(_permissionGrantedKey) ?? false;
  }

  Future<void> setUserInfo(String userInfo) async {
    await _prefs.setString(_userInfoKey, userInfo);
  }

  String? getUserInfo() {
    return _prefs.getString(_userInfoKey);
  }

  Future<void> removeUserInfo() async {
    await _prefs.remove(_userInfoKey);
  }

  // userInfo 退出登录需要清掉
  static const String _userInfoKey = 'current_login_user_info';

  // Permission status 退出登录不能清掉
  static const String _permissionGrantedKey = 'permission_granted';

  // Generic methods
  Future<void> setString(String key, String value) async {
    await _prefs.setString(key, value);
  }

  String? getString(String key) {
    return _prefs.getString(key);
  }

  Future<void> setBool(String key, bool value) async {
    await _prefs.setBool(key, value);
  }

  bool? getBool(String key) {
    return _prefs.getBool(key);
  }

  Future<void> setInt(String key, int value) async {
    await _prefs.setInt(key, value);
  }

  int? getInt(String key) {
    return _prefs.getInt(key);
  }

  Future<void> remove(String key) async {
    await _prefs.remove(key);
  }

  Future<void> clear() async {
    await _prefs.clear();
  }
}
