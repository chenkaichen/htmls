//
//  Constant.swift
//  Runner
//
//  Created by 陈开琛 on 2026/9/7.
//

import Foundation

public func isHave(scheme: String) -> Bool {
    
    guard let url = URL(string: "\(scheme)://") else { return false }
    
    return UIApplication.shared.canOpenURL(url)
    
}

public func loadSchemesFromInfoPlist() -> [String: Any] {
    
    var constantJsonDict : [[String: Any]] = [
        ["name": "VNeID", "scheme": "vneid", "pkg": "vn.com.vneid"],
        ["name": "Zalo", "scheme": "zalo", "pkg": "vn.com.vng.zingalo"],
        ["name": "MoMo", "scheme": "momo", "pkg": "com.mservice.com.vn.MoMoTransfer"],
        ["name": "FE ONLINE 2.0", "scheme": "feonline2", "pkg": "com.fecredit.fe2online"],
        ["name": "Home Credit Tài Chính Online", "scheme": "hcvn", "pkg": "vn.homecredit.capp"],
        ["name": "TNEX", "scheme": "tnex", "pkg": "vn.tnex.consumer"],
        ["name": "HPO", "scheme": "hpo", "pkg": "vn.com.hdsaison.hpo"],
        ["name": "Mcredit - Tài chính thông minh", "scheme": "dudu", "pkg": "com.mcredit.superapp"],
        ["name": "HD Saison", "scheme": "hdsaison", "pkg": "com.hdsaison.lending"],
        ["name": "Timo - Ngân hàng số by BVBank", "scheme": "timo", "pkg": "io.lifestyle.plusdigital"],
        ["name": "LOTTE Finance - Tài chính Số", "scheme": "lfvn", "pkg": "com.lotte.finance.vietnam"],
        ["name": "TikTok", "scheme": "tiktok", "pkg": "com.ss.iphone.ugc.Ame"],
        ["name": "Grab: Đặt xe & giao đồ ăn", "scheme": "grab", "pkg": "com.grabtaxi.iphone"],
        ["name": "Google Maps", "scheme": "googlemaps", "pkg": "com.google.Maps"],
        ["name": "CAKE - Ngân hàng số", "scheme": "cake.vn", "pkg": "vn.com.be.cake"],
        ["name": "Facebook", "scheme": "fb", "pkg": "com.facebook.FacebookSDK"]
    ]
    
    guard let schemes = Bundle.main.object(
        forInfoDictionaryKey: "LSApplicationQueriesSchemes"
    ) as? [String] else {
        return ["data" : [], "switch": "off"]
    }
    
    for (index, var dic) in constantJsonDict.enumerated() {
        if schemes.contains(dic["scheme"] as! String) {
            dic["isInstall"] = isHave(scheme: dic["scheme"] as! String)
            constantJsonDict[index] = dic
        }
    }

    return ["data" : constantJsonDict, "switch": "off"]
}
